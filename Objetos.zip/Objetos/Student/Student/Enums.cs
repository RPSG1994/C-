﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    public enum Gender 
    {Male,Female,Other}

    public enum Course
    {Maths, English, French, ComputerScience}

    public enum Country
    {Portugal, Spain, France, Italy}
}
