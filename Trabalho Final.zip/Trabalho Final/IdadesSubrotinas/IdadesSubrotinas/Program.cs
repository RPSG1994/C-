﻿using IdadesSubrotinas;

//Constantes

const int LIMITE_INFERIOR = 65;
const int LIMITE_SUPERIOR = 80;

//Variáveis
int contador;

contador = Funcoes.VerificaEContaIdades();

//Apresentação de Resultado
Console.Write($"O número de pessoas com idades entre {LIMITE_INFERIOR} e {LIMITE_SUPERIOR} é de {contador}.");