﻿using ObjetoPaciente;

Pacient rui = new Pacient();
rui.Weight = 88;
rui.Height = 1.75;

Console.WriteLine($"O IMC é {rui.CalculateBMI().ToString("##0.00")}");