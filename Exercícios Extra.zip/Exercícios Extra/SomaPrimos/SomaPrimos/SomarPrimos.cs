﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomaPrimos
{
    internal class SomarPrimos
    {
        /// <summary>
        /// Verificar se um numero é primo ou não.
        /// </summary>
        /// <param name="number"></param>
        /// <param name="number"></param>
        /// <returns></returns>

        public bool IsPrime(int number)
        {
            //Caso especial de -1, 0 ou 1 afirmar que o número não é primo
            int i;
            number = Math.Abs(number);

            if (number == 1 || number == 0)
                return false;

            //Testar
            for (i = 2; i < number; i++)
            {
                if (number % i == 0)
                    return false;
            }

            return true;
        }

        /// <summary>
        /// Troca os numeros se o primeiro for maior que o segundo
        /// </summary>
        /// <param name="lowerNumber"></param>
        /// <param name="higherNumber"></param>

        public (int, int) NumberSwap1(int lowerNumber, int higherNumber)
        {
            //Variáveis
            int auxiliaryNumber;

            //Retificar numeros trocados
            if (lowerNumber > higherNumber)
            {
                auxiliaryNumber = lowerNumber;
                lowerNumber = higherNumber;
                higherNumber = auxiliaryNumber;
            }
            return (lowerNumber, higherNumber);
        }

        /// <summary>
        /// Troca os numeros se o primeiro for maior que o segundo por referência
        /// </summary>
        /// <param name="lowerNumber"></param>
        /// <param name="higherNumber"></param>

        /public void NumberSwap2(ref int lowerNumber, ref int higherNumber)
        {
            //Variáveis
            int auxiliaryNumber;

            //Retificar numeros trocados
            if (lowerNumber > higherNumber)
            {
                auxiliaryNumber = lowerNumber;
                lowerNumber = higherNumber;
                higherNumber = auxiliaryNumber;
            }
        }

        /// </summary>
        /// Soma os primos no intervalo do menor numero para o maior.
        /// <param name="lowerNumber">Limite inferior do intervalo>
        /// <param name="higherNumber">Limite superior do intervalo>
        /// <returns></returns>

        public int SumPrime(int lowerNumber, int higherNumber)
        {
            {
                //Troca numeros
                (lowerNumber, higherNumber) = NumberSwap1(lowerNumber, higherNumber);

                //Troca numeros por referência
                //NumberSwap2(ref lowerNumber,ref higherNumber);

                int sumOfPrimes = 0;

                //Soma dos primos no intervalo

                for (int j = lowerNumber; j <= higherNumber; j++)
                {
                    if (IsPrime(j))
                    {
                        sumOfPrimes += j;
                    }
                }
                return sumOfPrimes;
            }
        }
        /// <summary>
        /// Dá os números primos entre o intervalo lower & higher com o separador escolhido pelo utilizador.
        /// </summary>
        /// <param name="lowerNumber"></param>
        /// <param name="higherNumber"></param>
        /// <param name="separadorLista"></param>
        /// <returns></returns>
        public string GivePrimes(int lowerNumber, int higherNumber, string separadorLista)
        {
            //Variáveis
            string listaPrimos = "";

            //Trocar se necessário
            NumberSwap1(lowerNumber, higherNumber);

            //Concatenar numeros primos entre lower e higher
            for (int j = lowerNumber; j <= higherNumber; j++)
                if (IsPrime(j))
                    listaPrimos += j + separadorLista;

            return listaPrimos;
        }
    }
}