﻿/* Autor: Rui Gonçalves
 * Data: 23-05-2023*/

//Constantes
const int NUMERO_IMPUTS = 3;

//Variáveis
int idade, contador;
double somaIdades = 0, media;

for (contador = 0; contador < NUMERO_IMPUTS; contador++)
{
    Console.Write($"Insira a idade da pessoa {contador + 1}:");
    idade = int.Parse(Console.ReadLine());
    do
    {
        Console.Write($"ERRO! Insira a idade da pessoa {contador + 1}:");
        idade = int.Parse(Console.ReadLine());
    } while (idade < 0);

    somaIdades += idade; //Deixar assim em vez de somaIdades += int.Parse(Console.ReadLine()) para facilitar a leitura do código
}

//Cálculo da Média
media = somaIdades / (contador == 0 ? 1 : contador);

//Apresentar resultado
Console.Write($"A média das idades introduzidas é de {media.ToString("###.00")} anos.");
