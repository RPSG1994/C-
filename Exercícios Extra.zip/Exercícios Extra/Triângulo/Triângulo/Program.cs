﻿/* Autor: Rui Gonçalves
 * Data: 15/05/2023*/

// Variáveis
float ladoA, ladoB, ladoC;

//Imputs e Verificações
Console.Write("Insira um dos lados do triângulo: ");
ladoA =int.Parse(Console.ReadLine());

while (ladoA <=0)
{
    Console.Write("Insira o primeiro dos lados do triângulo: ");
    ladoA = float.Parse(Console.ReadLine());
}

Console.Write("Insira o segundo dos lados do triângulo: ");
ladoB = float.Parse(Console.ReadLine());

while (ladoB <= 0)
{
    Console.Write("Insira o segundo dos lados do triângulo: ");
    ladoB = float.Parse(Console.ReadLine());
}

Console.Write("Insira o terceiro dos lados do triângulo: ");
ladoC = float.Parse(Console.ReadLine());

while (ladoC <= 0)
{
    Console.Write("Insira o terceiro dos lados do triângulo: ");
    ladoC = float.Parse(Console.ReadLine());
}

//Cálculos e verificações
if (ladoA < ladoB + ladoC && (Math.Pow(ladoA, 2) == Math.Pow(ladoB, 2) + Math.Pow(ladoC, 2) || Math.Pow(ladoB, 2) == Math.Pow(ladoA, 2) + Math.Pow(ladoC, 2) || Math.Pow(ladoC, 2) == Math.Pow(ladoA, 2) + Math.Pow(ladoB, 2)))
    Console.Write("Os lados inseridos formam um triângulo rectângulo.");
else if (ladoA < ladoB + ladoC && ladoB < ladoA + ladoC && ladoC < ladoA + ladoB)
    Console.Write("Os lados inseridos formam um triângulo.");
else
    Console.Write("Os lados inseridos não formam um triângulo.");