﻿/* Autor: Rui Gonçalves
 * Data: 11/05/2023*/

//Escreva um switch que receba uma letra e determine se é uma vogal ou uma consoante.

// variáveis
string classificacao, letraInserida;

//pedir a letra
Console.Write("Insira uma letra: ");
letraInserida = Console.ReadLine().ToLower();

/*Apenas permitir que seja inserida 1 letra.
O "while" é uma estrutura de controle de fluxo em C# que permite a execução repetida de um bloco de código enquanto uma condição específica for verdadeira.
Char.IsLetter é um método da classe Char em C# que retorna true se o caracter especificado como argumento é uma letra e false caso contrário.
No trecho de código !Char.IsLetter(letraInserida[0]), estamos a utilizar o operador ! (not) para inverter o valor retornado pelo método Char.IsLetter.
A expressão letraInserida[0] está acessando o primeiro caracter da string letraInserida, uma vez que, no nosso caso, estamos verificando apenas a entrada do usuário de uma única letra. 
Por isso, utilizamos [0] para acessar o primeiro (e único) caractere da string.
Usou-se "ou" em fez de "e" porque queremos que ambas as condições sejam falsas e que retornem falso. Caso se colocasse um "e", caso apenas uma das condições fosse falsa, o loop acabava.*/

while (letraInserida.Length != 1 || !Char.IsLetter(letraInserida[0]))
{
    Console.Write("Deve inserir apenas uma letra. Tente de novo: ");
    letraInserida = Console.ReadLine();
}

//descobrir tipo de letra
switch (letraInserida)
{
    case "a": 
    case "e":
    case "i":
    case "o":
    case "u":
        classificacao = "vogal";
     default:
        classificacao = "consoante";
        break;
}
Console.Write($"A letra inserida foi uma {classificacao}.");