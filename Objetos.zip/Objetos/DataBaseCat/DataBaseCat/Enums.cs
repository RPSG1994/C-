﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseCat
{
     public enum Breed
    {Unknown, Siamese, Persian, MaineCoon, Bengal}

    public enum Color
    {Unknown, White, Black, Brown, Gray}

    public enum TextType
    {LowerCase, UpperCase, Raw}

}
