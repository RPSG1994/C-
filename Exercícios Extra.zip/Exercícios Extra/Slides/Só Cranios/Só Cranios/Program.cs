﻿/* Autor: Rui Gonçalves
 * Data: 23/05/2023*/

/*A Associação de estudantes de Escola Secundária “Só Crânios” está a organizar um concurso de matemática com o objetivo de encontrar os 3 melhores alunos à disciplina
A equipa organizadora do concurso necessita de uma aplicação que faça as inscrições de alunos, através da recolha do nome e da nota de 11 º ano a matemática.
O número de alunos inscritos no concurso nunca poderá ser inferior a 5 e superior a 10. 
No entanto, as inscrições terminam se a média das notas dos alunos inscritos atingir os 18 valores, desde que cumprido o preceito do mínimo de 5 alunos
inscritos. Caso um candidato tenha nota inferior a 14 valores, a sua inscrição é automaticamente recusada*/

//Variáveis

double notaMediaSelecionados = 18, notaMediaInscritos = 0, numeroInscricoes = 0, notaMatematica = 0, numeroSelecionados = 0, somaNotasSelecionados = 0, somaNotasInscritos = 0, somaNotasTotal = 0;
string listaNomes = "", nome = "", listaNotas = "";

//Recolha de Notas
while (numeroInscricoes != 10 && (numeroInscricoes < 5 || notaMediaInscritos <= 18))
{
    Console.Write($"Qual o nome do aluno? ");
    nome = Console.ReadLine();
    Console.Write($"Qual a nota a Matemática do aluno {nome}? ");
    notaMatematica = double.Parse(Console.ReadLine());

    if (notaMatematica <= 14)
        Console.WriteLine("Não é possível te inscreveres");

    else if (notaMediaSelecionados <= notaMatematica && numeroSelecionados < 3)
    {
        numeroInscricoes++;
        numeroSelecionados++;
        somaNotasSelecionados += notaMatematica;
        notaMediaSelecionados = somaNotasSelecionados / numeroSelecionados;
        listaNomes += nome;
        listaNomes += "; ";
        listaNotas += notaMatematica;
        listaNotas += "; ";
    }
    else
    {
        numeroInscricoes++;
        somaNotasInscritos += notaMatematica;
        somaNotasTotal = somaNotasInscritos + somaNotasSelecionados;
        notaMediaInscritos = somaNotasTotal / numeroInscricoes;
    }
}

// Verificação das Inscrições
if (numeroInscricoes < 5 || numeroInscricoes == 0)
{
    Console.WriteLine("Impossível calcular a média");
}

//Apresentação de resultados
Console.Write($"A equipa é formada pelos alunos: {listaNomes} cujas notas foram {listaNotas} a média das suas notas foi de {notaMediaSelecionados.ToString("##.0")}.");