﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Funcionalidades
{
    internal class UserInteraction
    {
        public int AskForInt(string question, int leftBound, int rightBound, string failMessage)
        {
            //Variáveis
            int answer;
            
            //Ask the question 
            Console.Write(question);

            //Get the int imput from user& verify the number
            do
            {
               
              answer = int.Parse(Console.ReadLine());

                if (answer < leftBound || answer > rightBound)
                Console.Write(failMessage);
                
            } while (answer < leftBound || answer > rightBound);

            //Return the integer to the user
            return answer;
        }
        public string AskForString(string question, TextType textType)
        {
            string answer;
            //Ask the question 
            
            Console.Write(question);

            //Get the strig imput from user and convert to textType
            
            answer = Console.ReadLine();

            //convert to textType
            switch (textType)
            {
                case TextType.LowerCase:
                    answer = answer.ToLower();
                    break;
                case TextType.UpperCase:
                    answer = answer.ToUpper();
                    break;
                case TextType.Raw:
                    break;
                default:
                    throw new Exception("ERRO! NÃO PODES!");
            }

            //Return the string to the user

            return answer;
        }

        public double AskForDouble (string question) 
        {
            //Ask the question 

            //Get the double imput from user

            //Return the double to the user

            return 0; 
        }

    }
}
