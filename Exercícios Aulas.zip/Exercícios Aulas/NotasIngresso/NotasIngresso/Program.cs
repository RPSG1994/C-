﻿/* Autor: Rui Gonçalves
Data:10-05-2023 */

//definir constantes
using System.ComponentModel.Design;

const int IDADE_MINIMA = 17;
const int MAT_MINIMA = 14;
const int MEDIA_MINIMA = 16;
const string SEPARADOR_ALUNOS = " ";

//definir variáveis
int idade1, idade2, idade3, mat1, mat2, mat3, pt1, pt2, pt3, contadoradmitidos = 0, contadornaoadmitidos = 0;
double media1, media2, media3;
string nome1, nome2, nome3;
string listaalunosadmitidos = "", listaalunosnaoadmitidos = "";

//recolha de dados
Console.Write("Nome 1: ");
nome1 = Console.ReadLine();
Console.Write("Idade 1: ");
idade1 = int.Parse(Console.ReadLine());
Console.Write("Nota Matemática 1: ");
mat1 = int.Parse(Console.ReadLine());
Console.Write("Nota Português 1: ");
pt1 = int.Parse(Console.ReadLine());
Console.Write("Nome 2: ");
nome2 = Console.ReadLine();
Console.Write("Idade 2: ");
idade2 = int.Parse(Console.ReadLine());
Console.Write("Nota Matemática 2: ");
mat2 = int.Parse(Console.ReadLine());
Console.Write("Nota Português 2: ");
pt2 = int.Parse(Console.ReadLine());
Console.Write("Nome 3: ");
nome3 = Console.ReadLine();
Console.Write("Idade 3: ");
idade3 = int.Parse(Console.ReadLine());
Console.Write("Nota Matemática 3: ");
mat3 = int.Parse(Console.ReadLine());
Console.Write("Nota Português 3: ");
pt3 = int.Parse(Console.ReadLine());

//cálculo da média de português e matemática
media1 = (pt1 + mat1) / 2.0;
media2 = (pt2 + mat2) / 2.0;
media3 = (pt3 + mat3) / 2.0;

//testes lógicos de aceitação
if (idade1 >= IDADE_MINIMA && mat1 > MAT_MINIMA && media1 > MEDIA_MINIMA)
{
    contadoradmitidos++;
    listaalunosadmitidos += nome1 + SEPARADOR_ALUNOS;
}
else
{
    contadornaoadmitidos++;
    listaalunosnaoadmitidos += nome1 + SEPARADOR_ALUNOS;
}
if (idade2 >= IDADE_MINIMA && mat2 > MAT_MINIMA && media2 > MEDIA_MINIMA)
{ contadoradmitidos++;
    listaalunosadmitidos += nome2 + SEPARADOR_ALUNOS;
}

else
{ contadornaoadmitidos++;
listaalunosnaoadmitidos += nome2 + SEPARADOR_ALUNOS;
}

if (idade3 >= IDADE_MINIMA && mat3 > MAT_MINIMA && media3 > MEDIA_MINIMA)
{ contadoradmitidos++;

listaalunosadmitidos += nome3 + SEPARADOR_ALUNOS;
}

else
{contadornaoadmitidos++;
    listaalunosnaoadmitidos += nome3 + SEPARADOR_ALUNOS;
}

//Apresentação de resultados
Console.WriteLine($"O(s) aluno(s) aprovados são: {listaalunosadmitidos}");
Console.WriteLine($"A contagem dos aprovados é de {contadoradmitidos}");
Console.WriteLine($"O(s) aluno(s) não aprovados são: {listaalunosnaoadmitidos}");
Console.WriteLine($"A contagem dos não aprovados é de {contadornaoadmitidos}");
