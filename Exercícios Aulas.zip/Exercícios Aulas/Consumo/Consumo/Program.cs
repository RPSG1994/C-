﻿/* Autor: Rui Gonçalves
 * Data:09052023*/

//definir variáveis
float litros, km, consumo;
string matricula;

//atribuir valores às variáveis
litros = 57.8f; //fazer como inteiro
km = 801.1f;
matricula = "90-50-UH";

//fórmula de cálculo
consumo = 100 * litros / km;

//apresentar resultado
Console.WriteLine($"O automóvel com a matrícula {matricula} tem um consumo de {consumo.ToString("### ###.##")} l/100km."); //\n (new line) \t (tabulação) consumo.ToString("### ###.##"), arredondar com 2 casas décimas 