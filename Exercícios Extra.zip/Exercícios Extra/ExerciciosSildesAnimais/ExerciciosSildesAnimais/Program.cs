﻿/* Autor: Rui Gonçalves
 * Data: 20-05-2023*/

/* Umaloja de venda de animais pretende criar uma aplicação que automatize o processo de cálculo de PVP (preços de venda a publico) A margem a ser
praticada varia em função da família dos artigos */

//Constantes
const double MARGEM_COBRAS = 3.0;
const double MARGEM_RATOS = 4.0;
const double MARGEM_CAES = 9.0;
const double IVA = 23.0;

//Variáveis
double precoBase, margem, precoFinal;
int opcao;

//Recolha de dados
Console.Write("Insira o preço base : ");
precoBase = double.Parse(Console.ReadLine());

while (precoBase < 0)
{
    Console.Write("ERRO! VALOR INVÁLIDO! Insira o preço base : ");
    precoBase = double.Parse(Console.ReadLine());
}

Console.Write("Insira o animal (1 - Cobra; 4 - Rato ; 9 - Cães): ");
opcao = int.Parse(Console.ReadLine());

while (opcao != 1 && opcao != 4 && opcao != 9)
{
    Console.Write("ERRO! VALOR INVÁLIDO! Insira o preço base : ");
    precoBase = int.Parse(Console.ReadLine());
}

//Decisão
switch (opcao)
{
    case 1:
        margem = MARGEM_COBRAS;
        break;
    case 4:
        margem = MARGEM_RATOS;
        break;
    case 9:
        margem = MARGEM_CAES;
        break;
    default:
        Console.Write("IMPUT INVÁLIDO");
        margem = 0;
        break;
}

//Cálculo do Preço Final

precoFinal = precoBase * (1 + (margem / 100)) * (1 + (IVA / 100));

//Apresentação de resultados
Console.Write($"O valor final do animal é de{precoFinal.ToString("### ###.00")} euros.");