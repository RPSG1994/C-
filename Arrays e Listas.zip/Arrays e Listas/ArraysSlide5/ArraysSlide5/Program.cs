﻿// variáveis
double[] numeros;
int quantidade;

//Pede a quantidade de doubles
quantidade = PedeQuantidade();

// Carregar os valores
numeros = RecolheNumeros(quantidade);

//Mostra os valores
Mostra("Os números inseridos foram", numeros);

static int PedeQuantidade()
{
    int quantidade;
    Console.Write("Qual a quantidade de números que quer inserir? ");
    quantidade = int.Parse(Console.ReadLine());

    return quantidade;
}

static double[] RecolheNumeros(int quantity)
{
    // variáveis
    double[] numeros = new double[quantity];
    double numero;
    int i = 0;

    Console.Write($"Insira o número {i + 1}: ");
    numero = double.Parse(Console.ReadLine());

    // recolher as notas
    for (; i < quantity && numero >= 0;)
    {
        numeros[i] = numero;
        i++;
        Console.Write($"Insira o número {i + 1}: ");
        numero = double.Parse(Console.ReadLine());
    }

    // devolver o array de notas
    return numeros;
}
static void Mostra(string titulo, double[] numeros)
{
    // apresenta relatório
    Console.WriteLine(titulo);

    // apresenta elementos
    for (int i = 0; i < numeros.Length; i++)
    {
        if (numeros[i] == 0)
            Console.Write(" ");
        else Console.Write($"{numeros[i]}  ");
    }
}