﻿/* Autor: Rui Gonçalves
 * Data: 18/05/2023*/

//Imprima na consola uma lista de alunos, cuja idade seja inferior a 24 anos. Evolua a aplicação para que registar qual foi o aluno mais velho e mais novo inserido.
const int MENOS_VINTE_E_QUATRO = 24;
const int IDADE_ADMISSIVEL_MINIMA = 0;
const int IDADE_ADMISSIVEL_MAXIMA = 120;

//Variáveis
string listaAlunos = "";
string nomeAluno = "";
string nomeAlunoMaisVelho = "";
string nomeAlunoMaisNovo = "";
int idadeAluno = 0, idadeMaxima = 0, idadeMinima = 1000;

//Recolha de nomes, maior e menor idade
while (nomeAluno.ToLower() != "sair")
{
    Console.Write("Como se chama o aluno? (ou 'sair' para sair) ");
    nomeAluno = Console.ReadLine();

    if (nomeAluno.ToLower() == "sair")
        continue;

    Console.Write("Qual a idade do aluno? ");
    idadeAluno = int.Parse(Console.ReadLine());

    while (idadeAluno < IDADE_ADMISSIVEL_MINIMA || idadeAluno > IDADE_ADMISSIVEL_MAXIMA)
    {
        Console.Write("ERRO! IDADE INVÁLIDA! Qual a idade do aluno? ");
        idadeAluno = int.Parse(Console.ReadLine());
    }

    //Testes Lógicos

    if (idadeAluno < MENOS_VINTE_E_QUATRO)
    {
        listaAlunos += nomeAluno;
        listaAlunos += "; ";
    }
    if (idadeAluno > idadeMaxima)
    {
        nomeAlunoMaisVelho = nomeAluno;
        nomeAlunoMaisVelho += "; ";
        idadeMaxima = idadeAluno;
    }
    else if (idadeAluno == idadeMaxima)
    {
        nomeAlunoMaisVelho += nomeAluno;
        nomeAlunoMaisVelho += "; ";
    }
    if (idadeAluno < idadeMinima)
    {
        nomeAlunoMaisNovo = nomeAluno;
        nomeAlunoMaisNovo += "; ";
        idadeMinima = idadeAluno;
    }
    else if (idadeAluno == idadeMinima)
    {
        nomeAlunoMaisNovo += nomeAluno;
        nomeAlunoMaisNovo += "; ";
    }
}

//Apresentação de resultados
Console.WriteLine($"A lista dos alunos com menos de 24 anos é {listaAlunos}");
Console.WriteLine($"O(s) nome(s) do(s) aluno(s) mais velho(s) é(são) {nomeAlunoMaisVelho} que tem {idadeMaxima} anos.");
Console.WriteLine($"O(s) nome(s) do(s) aluno(s) mais novo(s) é(são) {nomeAlunoMaisNovo} que tem {idadeMinima} anos.");