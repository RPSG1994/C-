﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetoCao
{
    internal class Cao
    {
        public Cao()
        {
            IsAwake = false;
            IsEating = false;
        }

        // Properties
        public string ChipNumber { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public bool IsAwake { get; set; }
        public bool IsEating { get; set; }

        public void Awake()
        {
            if (IsAwake)
            {
                Console.WriteLine($"O {Name} já está acordado!");
            }

            Console.WriteLine($"The {Name} is awakening...");
        }

        public void Bark()
        {
            if (!IsAwake)
            {
                Console.WriteLine("O cão está a dormir! Não pode ladrar.");
                return;
            }

            Console.WriteLine($"O {Name} está a ladrar.");
        }

        public void Eat()
        {
            if (!IsAwake)
            {
                Console.WriteLine("O cão está a dormir! Não pode comer.");
                return;
            }

            Console.WriteLine($"O {Name} está a comer.");
        }

        public int GetHumanAge()
        {
            return Age * 7;
        }
    }
}