﻿/* Autor: Rui Gonçalves
 * Data 11/05/2023*/

//variáveis
string animal1, animal2, animal3;
int contadorCaes = 0, contadorGatos = 0, contadorPatos = 0;

// pedir tipo de animal
Console.Write("Insira o animal 1: ");
animal1 = Console.ReadLine(); //Console.Read lê apenas um caracter
Console.Write("Insira o animal 2: ");
animal2 = Console.ReadLine();
Console.Write("Insira o animal 3: ");
animal3 = Console.ReadLine();

//contador mediante o tipo
switch (animal1)
{
	case "gato":
		contadorGatos++;
		break;
	case "cão": case "cao": case "Cão": case "CAO":
		contadorCaes++;
		break;
	case "pato":
		contadorPatos++;
		break;
	default:
		Console.WriteLine("Não encontrado");
		break;
}
switch (animal2)
{
    case "gato":
        contadorGatos++;
        break;
    case "cão":
    case "cao":
    case "Cão":
    case "CAO":
        contadorCaes++;
        break;
    case "pato":
        contadorPatos++;
        break;
    default:
        Console.WriteLine("Não encontrado");
        break;
}
switch (animal3)
{
            case "gato":
                contadorGatos++;
                break;
            case "cão":
            case "cao":
            case "Cão":
            case "CAO":
                contadorCaes++;
                break;
            case "pato":
                contadorPatos++;
                break;
            default:
                Console.WriteLine("Não encontrado");
                break;
}
 //apresentar resultados
Console.WriteLine($"O número de gatos é {contadorGatos}");
Console.WriteLine($"O número de cães é {contadorCaes}");
Console.WriteLine($"O número de patos é {contadorPatos}");