﻿/* Autor: Rui Gonçalves
 * Data: 15/05/2023*/

//Constantes
const double PI = Math.PI;
const double DIAMETRO_MAIS_CEM = 2;
const double DIAMETRO_MENOS_CINQUENTA = 6;
const double DIAMETRO_ENTRE_CINQUENTA_CEM = 4;
const double CEM = 100;
const double CINQUENTA = 50;
const double QUATRO = 4;
const double DOIS = 2;

//Variáveis
double carga, tensao, n, diametro;

//Imputs e verificações
Console.Write("Insira o valor da carga: ");
carga = float.Parse(Console.ReadLine());

while (carga < 0)
{
    Console.Write("Insira o valor da carga: ");
    carga = float.Parse(Console.ReadLine());
}

Console.Write("Insira o valor do diâmetro: ");
diametro = float.Parse(Console.ReadLine());

while (diametro <= 0)
{
    Console.Write("Insira o valor do diâmetro: ");
    diametro = float.Parse(Console.ReadLine());
}

//Determinar o valor de n
if (diametro > CEM)
    n = DIAMETRO_MAIS_CEM;
else if (diametro < CINQUENTA)
    n = DIAMETRO_MENOS_CINQUENTA;
else
    n = DIAMETRO_ENTRE_CINQUENTA_CEM;

//Cálculo do valor de tensão
tensao = (QUATRO * carga) / (PI * Math.Pow(diametro, DOIS)) * n;

//Apresentação do resultado
Console.Write($"O valor da tensão da barra com diametro de {diametro} é{tensao.ToString("### ###.###")} quando submetida a uma carga de {carga}.");