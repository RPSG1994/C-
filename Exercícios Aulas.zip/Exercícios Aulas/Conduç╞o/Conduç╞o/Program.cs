﻿//Declarar constantes
const int IDADE_MINIMA = 22;
const float ALTURA_MINIMA = 1.50f;

//Declarar variáveis e atribuir valores
string nome;
int idade;
float altura;
bool carta;

//Atribuir valores às variáveis
nome = "António";
idade = 20;
altura = 1.65f;
carta = false;

//Teste lógico
if (altura >= ALTURA_MINIMA && idade >= IDADE_MINIMA || carta)
    Console.WriteLine($"O {nome} consegue conduzir");
else
    Console.WriteLine($"O {nome} não consegue conduzir");