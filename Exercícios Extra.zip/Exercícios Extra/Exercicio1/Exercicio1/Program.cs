﻿/* Autor: Rui Gonçalves
 * Data: 10/05/2023*/

//definir variáveis
int a = 3, b = 7, c = 4;
bool res1, res2, res3, res4, res5;

//Testes lógicos
if (res1 = (a + b) > b) ;
Console.WriteLine($"A afirmação 1 é {res1}");

if (res2 = b >= a + 2) ;
Console.WriteLine($"A afirmação 2 é {res2}");

if (res3 = c == b-a) ;
Console.WriteLine($"A afirmação 3 é {res3}");

if (res4 = (b + a) <= c) ;
Console.WriteLine($"A afirmação 4 é {res4}");

if (res5 = c + a > b) ;
Console.WriteLine($"A afirmação 5 é {res5}");