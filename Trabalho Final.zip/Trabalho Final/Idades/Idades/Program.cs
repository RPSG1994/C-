﻿/* Autor: Rui Gonçalves
 * Data: 24-05-2023 */

//Desenvolva um programa que receba um número indefinido de idades e que mostre na consola a quantidade de pessoas que 65 ≤𝑖𝑑𝑎𝑑𝑒 <80.

//Constantes
using System.ComponentModel.Design;

const int LIMITE_INFERIOR = 65;
const int LIMITE_SUPERIOR = 80;
const int IDADE_MINIMA = 0;
const int IDADE_MAXIMA = 120;

//Variáveis
int contador = 0, idade;

do
{
    //Pedido de imput da idade
    Console.Write("Qual a idade da pessoa? (Insira -1 para terminar o registo): ");
    idade = int.Parse(Console.ReadLine());

    if (idade == -1)
        break;

    else if (idade >= LIMITE_INFERIOR && idade < LIMITE_SUPERIOR)
        contador++;

    while (idade > IDADE_MINIMA && idade < IDADE_MAXIMA)
    {
        Console.Write("ERRO! Qual a idade da pessoa? (Insira -1 para terminar o registo): ");
        idade = int.Parse(Console.ReadLine());
    }

} while (idade != -1);

//Apresentação de Resultados
Console.Write($"O número de pessoas com idades entre {LIMITE_INFERIOR} e {LIMITE_SUPERIOR} é de {contador}.");