﻿using FlexBus;

string licensePlate = "", makeInput = "";

//Asks and receives the licence plate from the bus
Console.Write("Digite a matrícula do autocarro: ");
licensePlate = Console.ReadLine();

//Asks and receives the manufacture from the bus
Console.Write("Digite a marca do autocarro: ");
makeInput = Console.ReadLine();

//Cria o primeiro autocarro
Bus bus = new Bus(licensePlate, makeInput);

//Imprime na consola toda a informação
Console.WriteLine("================ APLICAÇÃO CLIENTE ===============================");
Console.WriteLine($"O NextId do próximo bus: {Bus.GetNextId()}");
Console.WriteLine($"A LicensePlate do bus criado: {bus.GetLicencePlate()}");
Console.WriteLine($"A Marca do bus: {bus.GetMake()}");
Console.WriteLine($"O peso do bus: {bus.GetWeight()}");