﻿/* Autor: Rui Gonçalves
 * Data: 20-05-2023*/

/* A secretaria de uma escola necessita de uma aplicação que permita calcular a média, nota máxima e mínima de uma turma à disciplina de Geometria.
 * Aaplicação deve receber o número de alunos existentes e solicitar as notas apenas para essa quantidade de estudantes. */

//Constantes
const int NOTA_MAXIMA = 20;

//Variáveis
int nota=0, numeroAlunos = 0, somaNotas=0;
double mediaNotas=0, notaMaxima=0, notaMinima=20;

//Criação do loop
while (nota<NOTA_MAXIMA)
{
    Console.Write($"Insira a nota do aluno {numeroAlunos+1}: ");
    nota=int.Parse(Console.ReadLine());
    if (nota > NOTA_MAXIMA)
        continue;
    if (nota > notaMaxima)
        notaMaxima = nota;
    else if (nota < notaMinima)
        notaMinima = nota;

    numeroAlunos++;
    somaNotas += nota;
    mediaNotas = somaNotas / numeroAlunos;
}

Console.WriteLine($"A média da turma de Geometria A é de {mediaNotas.ToString("###.#")}.");
Console.WriteLine($"A nota mais alta da turma de Geometria A é de {notaMaxima}.");
Console.WriteLine($"A nota mais baixa da turma de Geometria A é de {notaMinima}.");