﻿/* Autor: Rui Gonçalves
 * Data: 23/05/2023*/

//Variáveis
int dificuldade, numeroObjetivo, palpite;
int maxTentativas;
int limiteInferior, limiteSuperior;

Random random = new Random();

//Criação do visor de input
Console.WriteLine("**********************JOGO: ADIVINHA O NÚMERO*******************");
Console.Write("Qual a dificuldade que queres jogar? (1 - Iniciante [1;10]; 2 - Médio [1;30]; 3 - Experiente [1;50]) ");
dificuldade = int.Parse(Console.ReadLine());

// Definir limites e quantidade de tentativas com base na dificuldade
switch (dificuldade)
{
    case 1:
        limiteInferior = 1;
        limiteSuperior = 10;
        maxTentativas = 3;
        break;

    case 2:
        limiteInferior = 1;
        limiteSuperior = 30;
        maxTentativas = 10;
        break;

    case 3:
        limiteInferior = 1;
        limiteSuperior = 50;
        maxTentativas = 15;
        break;

    default:
        throw new Exception("Há um caminho a ser seguido que não está a ser corretamente programado");        
        return;
}

// Gerar número objetivo aleatório dentro dos limites definidos
numeroObjetivo = random.Next(limiteInferior, limiteSuperior);

// Iniciar o jogo
for (int tentativa = 0; tentativa < maxTentativas; tentativa++)
{
    Console.Write($"Qual é o teu {tentativa+1}º palpite? ");
    palpite = int.Parse(Console.ReadLine());

    if (palpite < numeroObjetivo)
        Console.WriteLine($"O número objetivo é maior do que o teu palpite {tentativa + 1}. ");
    else if (palpite > numeroObjetivo)
        Console.WriteLine($"O número objetivo é menor do que o teu palpite {tentativa + 1}. ");
    else
    {
        Console.WriteLine("Parabéns, acertaste no número pretendido!");
        return;
    }
}

Console.WriteLine($"QUE PENA! Não acertaste! O número correto era {numeroObjetivo}!");
