﻿using ArraysCompleto;

Student student1 = new Student(100, "Manuel", 16);
Student student2 = new Student(101, "Pedro", 13);
Student student3 = new Student(102, "Maria", 18);

Students.Add(student1);
Students.Add(student2);
Students.Add(student3);

Console.WriteLine(Students.GetGradeAverage());