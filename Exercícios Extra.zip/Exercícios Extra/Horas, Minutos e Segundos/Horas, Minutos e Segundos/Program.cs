﻿/* Autor: Rui Gonçalves
 * Data: 15/05/2023*/

//Definir variáveis
int horas1, minutos1, segundos1, horas2, minutos2, segundos2, diferencasegundos;
float diferencaMinutos, diferencaHoras;

//Imput de valores
Console.Write("Insira o valor da primera hora:");
horas1 = int.Parse(Console.ReadLine());

while (horas1 < 0 || horas1 > 23)
{
    Console.Write("ERRO! Insira o valor da primera hora: ");
    horas1 = int.Parse(Console.ReadLine());
}

Console.Write("Insira o valor dos minutos da primeira hora: ");
minutos1 = int.Parse(Console.ReadLine());

while (minutos1 < 0 || minutos1 > 59)
{
    Console.Write("ERRO! Insira o valor dos minutos da primeira hora: ");
    minutos1 = int.Parse(Console.ReadLine());
}

Console.Write("Insira o valor dos segundos da primera hora:");
segundos1 = int.Parse(Console.ReadLine());

while (segundos1 < 0 || segundos1 > 59)
{
    Console.Write("ERRO! Insira o valor dos segundos da primera hora:");
    segundos1 = int.Parse(Console.ReadLine());
}

Console.Write("Insira o valor da segunda hora:");
horas2 = int.Parse(Console.ReadLine());

while (horas2 < 0 || horas2 > 23)
{
    Console.Write("ERRO! Insira o valor da primera hora: ");
    horas2 = int.Parse(Console.ReadLine());
}

Console.Write("Insira o valor dos minutos da primeira hora: ");
minutos2 = int.Parse(Console.ReadLine());

while (minutos2 < 0 || minutos2 > 59)
{
    Console.Write("ERRO! Insira o valor dos minutos da primeira hora: ");
    minutos2 = int.Parse(Console.ReadLine());
}

Console.Write("Insira o valor dos segundos da primera hora:");
segundos2 = int.Parse(Console.ReadLine());

while (segundos2 < 0 || segundos2 > 59)
{
    Console.Write("ERRO! Insira o valor dos segundos da primera hora:");
    segundos2 = int.Parse(Console.ReadLine());
}

//Cálculo da diferença
diferencasegundos = (horas1 - horas2) * 3600 + (minutos1 - minutos2) * 60 + (segundos1 - segundos2);
diferencaMinutos = diferencasegundos / 60;
diferencaHoras = diferencaMinutos / 60;

//Apresentação de resultados
Console.WriteLine($"A diferença entre as duas horas é de {diferencasegundos} segundos ou{diferencaMinutos.ToString("### ###.##")} minutos ou de{diferencaHoras.ToString("### ###.##")} horas.");
