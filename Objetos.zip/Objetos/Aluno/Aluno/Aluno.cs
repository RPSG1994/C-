﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Turma
{
    public class Aluno
    {
        //Propriedades

        public int Numero { get; set; }

        public string Nome { get; set; }

        public double Nota1 { get; set; }

        public double Nota2 { get; set; }

        public double Nota3 { get; set; }

        //Métodos
        public double DaMedia()
        {
            return CalculaMedia(Nota1, Nota2, Nota3);
        }
        public bool EstaAprovado(double Nota1, double Nota2, double Nota3)
        {
            return DaMedia() >= 10;
        }
        public bool EstariaAprovado(double Nota1, double Nota2, double Nota3)
        {
            return CalculaMedia(Nota1, Nota2, Nota3) >= 10;
        }
        public double CalculaMedia(double valor1, double valor2, double valor3)
        {
            return ((valor1 + valor2 + valor3) / 3);
        }
    }
}