﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysExercício1
{
    internal class Classes
    {
        public static int PedeQuantidade()
        {
            int quantidade;
            Console.Write("Qual a quantidade de números que quer inserir? ");
            quantidade = int.Parse(Console.ReadLine());
            return quantidade;
        }

        public static double[] RecolheNumeros(int quantity)
        {
            // variáveis
            double[] numeros = new double[quantity];
            double numero;
            int i = 0;

            do
            {
                Console.Write($"Insira o número {i + 1}: ");
                numero = double.Parse(Console.ReadLine());
                numeros[i] = numero;
                i++;
            } while (i < quantity);

            // devolver o array de números
            return numeros;
        }

        public static double[] InverteNumeros(double[] numeros)
        {
            double[] numerosInvertidos = new double[numeros.Length];

            for (int i = 0; i < numeros.Length; i++)
            {
                numerosInvertidos[i] = numeros[i] * -1;
            }

            return numerosInvertidos;
        }

        public static void Mostra(string titulo, double[] numeros)
        {
            // apresenta relatório
            Console.WriteLine(titulo);

            // apresenta elementos
            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] == 0)
                    Console.Write(" ");
                else
                    Console.Write($"{numeros[i]}  ");
            }
            Console.WriteLine();
        }
    }
}