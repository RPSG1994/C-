﻿using ArraysExercício1;

// variáveis
double[] numeros;
double[] inverte;
int quantidade;

// Pede a quantidade de números
quantidade = Classes.PedeQuantidade();

// Carregar os valores
numeros = Classes.RecolheNumeros(quantidade);

// Inverte os valores
inverte = Classes.InverteNumeros(numeros);

// Mostra os valores
Classes.Mostra("Os números inseridos foram:", numeros);
Classes.Mostra("Os números inseridos invertidos foram:", inverte);