﻿/* Autor: Rui Gonçalves
 * Data: 11/05/2023*/

//variáveis
string descricao, codigo;

//Recolha de dados
Console.Write("Introduza o código (possibilidades - a1; a2; a3 ou a4): ");
codigo = Console.ReadLine().ToLower();

//
while (codigo != "a1" && codigo != "a2" && codigo != "a3" && codigo != "a4")
{
    Console.Write("Produto não encontrado. Reintroduza o código (possibilidades - a1; a2; a3 ou a4): ");
    codigo = Console.ReadLine().ToLower();
}

//determinar tipo de produto
switch (codigo)
{
    case "a1":
        descricao = "Folha de Papel";
        break;
    case "a2":
        descricao = "Livro";
        break;
    case "a3":
        descricao = "Caneta";
        break;
    case "a4":
        descricao = "Compasso";
        break;
    default:
        descricao = " ";
        Console.Write("Produto não encontrado");
        return;
        break;
}

//Apresentação do produto
Console.Write($"O código {codigo} corresponde ao produto: {descricao}.");