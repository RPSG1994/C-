﻿/* Autor: Rui Gonçalves
 * Data: 18/05/2023*/

//Crie uma aplicação que conte os visitantes
const int CINCO = 5;
const int OITO = 8;
const int CATORZE = 14;
const int IDADE_ADMISSIVEL_MINIMA = 0;
const int IDADE_ADMISSIVEL_MAXIMA = 120;

//Variáveis
int contadorMenosDeCinco = 0, contadorEntreCincoEOito = 0, contadorEntreOitoECatorze = 0, contadorMaisDeCatorze = 0;
int idade = 0;

Console.Write("Que idade tem o visitante? (Colocar -1 para parar) ");
idade = int.Parse(Console.ReadLine());

//Recolha de nomes, maior e menor idade
while (idade != -1)
{
    if (idade < IDADE_ADMISSIVEL_MINIMA || idade > IDADE_ADMISSIVEL_MAXIMA)
    {
        Console.Write("ERRO! IDADE INVÁLIDA! Qual a idade do visitante? ");
        idade = int.Parse(Console.ReadLine());
    }    
    
    if (idade >= IDADE_ADMISSIVEL_MINIMA && idade < CINCO)
        contadorMenosDeCinco++;
    else if (idade >= CINCO && idade < OITO) 
        contadorEntreCincoEOito++;
    else if (idade >= OITO && idade < CATORZE)
        contadorEntreOitoECatorze++;
    else
        contadorMaisDeCatorze++;
}

//Apresentação de resultados
Console.WriteLine($"O número de visitantes com menos de {CINCO} anos é {contadorMenosDeCinco}.");
Console.WriteLine($"O número de visitantes entre {CINCO} e {OITO} anos é {contadorEntreCincoEOito}.");
Console.WriteLine($"O número de visitantes entre {OITO} e {CATORZE} anos é {contadorEntreOitoECatorze}.");
Console.WriteLine($"O número de visitantes com mais de {CATORZE} anos é {contadorMaisDeCatorze}.");