﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Objetos
{
    internal class Carro
    {
        //Construtores
        public Carro() 
        {
            Desliga();
        }

        //Propriedades
        public string Matricula { get; set; }
        public string Marca { get; set; }
        public string Cor { get; set; }
        public int Km { get; set; }
        public int Ano { get; set; }

        //Métodos
        public void Liga() 
        {
           
        }

        public void Desliga()
        {

        }
        public string DaMatricula()
        {
            return Matricula;
        }
        public int DaKm()
        {
            return 200000;
        }

        public string DaCor()
        {
            return "Cinza";
        }

        public int DaAno()
        {
            return 2002;
        }
        //Eventos
        //OnLowFuel
        //OnLowPressure
    }
}
