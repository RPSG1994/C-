﻿/*Autor: Rui Gonçalves
 * Data: 23/05/2023

/*Um centro comercial pretende adequar um pouco mais a decoração do seu espaço de lazer e de alimentação à faixa etária dos seus visitantes Para isso, no
próximo fim de semana, irá recolher informação das pessoas que lá entram, com o objetivo de determinar: 
O número total de visitantes femininos e masculinos
O número de visitantes com idade compreendida entre os 10 e 16 anos e os 16 e 24 anos*/

//Constantes
const int DEZ_ANOS = 10;
const int DEZASSEIS_ANOS = 16;
const int VINTE_E_QUATRO_ANOS = 24;

//Variáveis
string genero;
int idade, contadorHomens = 0, contadorMulheres = 0, contadorAdolescentes = 0, contadorAdultos = 0;

do
{
    Console.Write("Qual o género do visitante? (Inserir algo diferente de M ou F para sair) ");
    genero = Console.ReadLine().ToUpper();

    if (genero == "M")
        contadorHomens++;
    else if (genero == "F")
        contadorMulheres++;
    else
        continue;

    Console.Write("Qual a idade do visitante? (Inserir algo diferente de M ou F para sair) ");
    idade = int.Parse(Console.ReadLine());

    if (idade >= DEZ_ANOS && idade < DEZASSEIS_ANOS)
        contadorAdolescentes++;
    else if (idade >=DEZASSEIS_ANOS && idade <VINTE_E_QUATRO_ANOS)
        contadorAdultos++;
} while (genero == "M" || genero == "F");

Console.WriteLine($"O número de visitantes homens foi de {contadorHomens} e de mulheres foi {contadorMulheres}.");
Console.WriteLine($"O número de visitantes entre {DEZ_ANOS} e {DEZASSEIS_ANOS} foi de {contadorAdolescentes} e entre {DEZASSEIS_ANOS} e {VINTE_E_QUATRO_ANOS} foi {contadorAdultos}.");