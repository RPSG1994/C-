﻿using HospitalSubrotinas;

//Variáveis
double percentagem, mediaTempoDeEspera;

//Avaliar Condições
(int contadorMulheres, int contadorMulheresMaisDuasHoras, int contadorHomensMaisDuasHoras, int contadorHomensAdultosQueGostaram, double somaTempoDeEspera, int contadorMulheresNaoGostaram) = Funcoes.AvaliarCondicoes();

//Cálculos
mediaTempoDeEspera = Funcoes.CalculoMediaTempoEspera(somaTempoDeEspera, contadorMulheresNaoGostaram);
percentagem = Funcoes.CalculoPercentagem(contadorMulheresNaoGostaram, contadorMulheres);

//Apresentação de Resultados
Console.WriteLine($"O número de inquiridos do género feminino, que esperaram mais de 2 horas para serem atendidos foi de {contadorMulheresMaisDuasHoras} e do género masculino é de {contadorHomensMaisDuasHoras}.");
Console.WriteLine($"A percentagem de pacientes do género feminino que não gostaram do atendimento do profissional de saúde que os atendeu foi de {percentagem.ToString("##0.00")}%.");
Console.WriteLine($"A quantidade de pacientes de género masculino, maiores de idade, que gostaram do atendimento do médico que os atendeu foi de {contadorHomensAdultosQueGostaram}.");
Console.WriteLine($"A média do tempo de espera dos pacientes femininos que não gostaram do atendimento do profissional de saúde foi de {mediaTempoDeEspera.ToString("##0.00")} horas.");