﻿/* Autor: Rui Gonçalves
 * Data:20-05-2023*/

//definir variáveis
double peso, altura, imc;
string nome, categoria;

//Imputs
Console.Write("Insira o nome da pessoa: ");
nome = Console.ReadLine();
Console.Write("Insira o peso da pessoa: ");
peso = float.Parse(Console.ReadLine());

while (peso<0)
{
    Console.Write("Insira o peso da pessoa: ");
    peso = float.Parse(Console.ReadLine());
}

Console.Write("Insira a altura da pessoa: ");
altura = double.Parse(Console.ReadLine());

while (altura < 0)
{
    Console.Write("Insira o peso da pessoa: ");
    peso = float.Parse(Console.ReadLine());
}


//fórmula de cálculo
imc = peso / (altura * altura);

//Decisão da categoria
if (imc <= 18.5)
    categoria = "Peso Abaixo do Recomendado";
else if (imc > 18.5 && imc <= 25)
    categoria = "Peso Normal";
else if (imc > 25 && imc <= 30)
    categoria = "Peso Acima do Recomendado";
else
    categoria = "Peso Muito Acima do Recomendado (Obesidade)";

//Apresentação de resultados
Console.Write($"A pessoa {nome} tem um IMC de{imc.ToString("### ###.00")} a que corresponde a categoria: {categoria}.");