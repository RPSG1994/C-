﻿/* Autor: Rui Goncalves
 * Data:09052023
 */
//declarar variáveis
int idade1, idade2, soma;
double media;
//atribuir valores às variáveis (idades)
idade1 = 15;
idade2 = 20;

//somar as idades
soma = idade1 + idade2;

//dividir pelo número de idades
media = soma / 2.0;

//apresentar a média
Console.WriteLine($"A media entre {idade1} e {idade2}: {media}.");


Console.WriteLine("Programa de Testes");
