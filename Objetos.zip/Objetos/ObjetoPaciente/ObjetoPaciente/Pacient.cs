﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace ObjetoPaciente
{
    internal class Pacient
    {
        //Properties

        public int Id { get; set; }
        /// <summary>
        /// Identifica o paciente
        /// </summary>

        public string Name { get; set; }
        /// <summary>
        /// Identifica o nome
        /// </summary>

        public double Weight { get; set; }
        /// <summary>
        /// Identifica o peso
        /// </summary>

        public double Height { get; set; }
        /// <summary>
        /// Identifica a altura
        /// </summary>


        public double CalculateBMI()
            ///Cálculo do BMI ou IMC
        {
            return Weight / (Height * Height);
        }
    }
}