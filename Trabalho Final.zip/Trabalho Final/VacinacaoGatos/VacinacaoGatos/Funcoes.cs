﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VacinacaoGatos
{
    internal class Funcoes
    {
        const int DESCONTO_UM = 10;
        const int DESCONTO_DOIS = 9;
        const int DESCONTO_TRES = 8;
        const int DESCONTO_QUATRO = 7;
        const int DESCONTO_CINCO = 5;
        const int COMPRIMENTO_UM = 6;
        const int COMPRIMENTO_DOIS = 10;
        const int COMPRIMENTO_TRES = 15;
        const int COMPRIMENTO_QUATRO = 18;
        const int COMPRIMENTO_CINCO = 25;

        /// <summary>
        /// Recebe e verifica o comprimento do gato
        /// </summary>
        /// <returns></returns>
        
        public static float VerificarComprimento()
        {
            float comprimento;
            Console.Write("Qual o comprimento do gato? ");
            comprimento = float.Parse(Console.ReadLine());

            if (comprimento < 0.0 || comprimento > 200.0)
            {
                Console.Write("COMPRIMENTO INVÁLIDO. Insira novamente o comprimento do gato: ");
            }
            return comprimento;
        }

        /// <summary>
        /// Recebe e verifica o género do gato
        /// </summary>
        /// <returns></returns>
        
        public static string VerificarGenero()
        {
            string genero;
            Console.Write("Qual o genero do gato? ");
            genero = Console.ReadLine().ToUpper();

            if (genero != "M" && genero != "F")
            {
                Console.Write("GÉNERO INVÁLIDO. Insira novamente o género do gato: ");
                genero = Console.ReadLine().ToUpper();
            }
            return genero;
        }

        /// <summary>
        /// Após verificar condições, retorna o valor do desconto
        /// </summary>
        /// <returns></returns>
        
        public static int CalcularDesconto(float comprimento, string genero)
        {
            int desconto;
            if (comprimento >= COMPRIMENTO_UM && comprimento < COMPRIMENTO_DOIS && genero == "F")
                desconto = DESCONTO_UM;
            else if (comprimento >= COMPRIMENTO_DOIS && comprimento < COMPRIMENTO_TRES && genero == "M")
                desconto = DESCONTO_DOIS;
            else if (comprimento >= COMPRIMENTO_TRES && comprimento < COMPRIMENTO_QUATRO && genero == "F")
                desconto = DESCONTO_TRES;
            else if (comprimento >= COMPRIMENTO_QUATRO && comprimento < COMPRIMENTO_CINCO && (genero == "M" || genero == "F"))
                desconto = DESCONTO_QUATRO;
            else
                desconto = DESCONTO_CINCO;
            return desconto;
        }
    }
}