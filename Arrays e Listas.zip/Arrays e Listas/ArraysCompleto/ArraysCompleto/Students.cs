﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ArraysCompleto
{
    internal static class Students
    {
        //Variáveis
        private static Student[] students = new Student[10];
        static int last = -1;

        public static int Count { get { return last + 1; } }


        public static void Add(Student student)
        {
            //Verifica se o espaço está todo ocupado ou não
            if (last == (students.Length - 1))
                throw new Exception("O espaço está todo ocupado");

            //Verifica se o aluno está repetido
            if (Exists(student.Id))
             throw new Exception("Aluno repetido!");
            
            last++;
            students[last] = student;
        }

        public static Student Get(int id)
        {
            //Variáveis
            int index;

            //O aluno tem que existir
            if (!Exists(id))
             throw new Exception("O aluno já existe!");

            //Saber em que índice é que o aluno está
            index = GetIndex(id);

            //Devolver o aluno que está no índice encontrado
            return students[index];
        }
        public static bool Exists(int id)
        {
            return GetIndex(id) > -1;
        }

        private static int GetIndex(int id)
        {
            //Variaveis
            int index = -1;
            //Procurar o índice a que corresponde o aluno

            for (int i = 0; i < Count && index == -1; i++)
                if (students[i].Id == id)
                    index = i;

            //Retorna o índice encontrado
            return index;
        }
        public static float GetGradeAverage()
        {
            //Variáveis
            float soma = 0;

            //Ver quantos alunos existem e somar a sua média

            for (int i = 0; i < Count; i++)
            {
                soma += students[i].Grade;  
            }

            //Devolver a média

            return soma / (Count == 0 ? 1 : Count);
        }

    }
}
