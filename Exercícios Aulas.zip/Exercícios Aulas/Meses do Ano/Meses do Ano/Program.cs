﻿/* Autor: Rui Gonçalves
 * Data: 11/05/2023*/
//Insira um número entre 1 e 12 [1 - Janeiro 12- Dezembro]

// variáveis
int numeroInserido;
string mesdoAno;

//pedir o dia
Console.Write("Insira um número entre 1 e 12 [1 - Janeiro 12- Dezembro]:");
numeroInserido = int.Parse(Console.ReadLine());

//Verificar se o número inserido é uma possibilidade. Só se saí do while com uma condição falsa e como queremos que ambas as condições estejam satisfeitas, usa-se um "ou".
while (numeroInserido < 1 || numeroInserido > 12)
{
    Console.WriteLine($"Mês {numeroInserido} não encontrado. Insira um número entre 1 e 12 [1 - Janeiro 12- Dezembro]: ");
    numeroInserido = int.Parse(Console.ReadLine());
}

//descobrir dia da semana
switch (numeroInserido)
{
    case 1:
        mesdoAno = "Janeiro";
        break;
    case 2:
        mesdoAno = "Fevereiro";
        break;
    case 3:
        mesdoAno = "Março";
        break;
    case 4:
        mesdoAno = "Abril";
        break;
    case 5:
        mesdoAno = "Maio";
        break;
    case 6:
        mesdoAno = "Junho";
        break;
    case 7:
        mesdoAno = "Julho";
        break;
    case 8:
        mesdoAno = "Agosto";
        break;
    case 9:
        mesdoAno = "Setembro";
        break;
    case 10:
        mesdoAno = "Outubro";
        break;
    case 11:
        mesdoAno = "Novembro";
        break;
    case 12:
        mesdoAno = "Dezembro";
        break;
    default:
        mesdoAno = "";
        break;
}
if (mesdoAno != "")
    Console.Write($"O mês do ano inserido é: {mesdoAno}.");
else
    Console.WriteLine("O mês do ano inserido é inválido.");