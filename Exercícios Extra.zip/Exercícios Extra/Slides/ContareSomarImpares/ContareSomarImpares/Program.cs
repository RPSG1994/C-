﻿/* Autor: Rui Gonçalves
 * Data: 23/05/2023*/

/*Há a necessidade de criar uma aplicação que, perante a introdução de dois limites inteiros, calcule a quantidade e o somatório de todos os valores ímpares
nesse intervalo Note que os limites do intervalo podem ser inseridos no menor para o maior ou do maior para o menor*/

//Constante
const int DIVISOR = 2;

//Variáveis
int numero1, numero2, contadorImpares = 0, contadorPares = 0, somaPares = 0, somaImpares = 0, numeroAuxiliar;
string impares = "";
string pares = "";

//Recolha dos Imputs
Console.Write("Qual é o primeiro numero que quer testar? (Insira número negativo para parar) ");
numero1 = int.Parse(Console.ReadLine());
Console.Write("Qual é o segundo numero que quer testar? (Insira número negativo para parar) ");
numero2 = int.Parse(Console.ReadLine());

if (numero1 > numero2)
{
    numeroAuxiliar = numero1;
    numero1 = numero2;
    numero2 = numeroAuxiliar;

}

while (numero1 <= numero2)
{
    if (numero1 % DIVISOR != 0)
    {
        impares += numero1; //Concatenar o resultado se for necessário concatenar .ToString
        impares += "; ";
        contadorImpares++;
        somaImpares += numero1;
    }
    else
    {
        pares += numero1; //Concatenar o resultado se for necessário concatenar .ToString
        pares += "; ";
        contadorPares++;
        somaPares += numero1;
    }
    numero1++;
}

Console.WriteLine($"No intervalo de números inseridos existem {contadorImpares} números impares, que são {impares} e a sua soma é de {somaImpares}.");
Console.WriteLine($"No intervalo de números inseridos existem {contadorPares} números pares, que são {pares} e a sua soma é {somaPares}.");