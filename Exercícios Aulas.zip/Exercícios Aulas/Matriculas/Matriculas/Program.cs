﻿/* Autor: Rui Gonçalves
 * Data: 18/05/2023*/

/*Crie uma aplicação que registe as matriculas que entram no parque do BragaParque para o evento de Natal.
O número de carros é indefinido.
Considere utilizar como condição de paragem, a matricula "FIM".*/

//Variáveis
string matricula = "";
string matriculasparque = "";
int contadorMatriculas = 0;

// Recolha da primeira matrícula
Console.Write($"Qual a matrícula {contadorMatriculas+1}? (ou 'FIM' para FIM): ");
matricula = Console.ReadLine().ToUpper();

//Recolha de matriculas
while (matricula != "FIM")
{
//Testar Validade de Matrícula

    if (matricula == "")
    {
    Console.Write("Matrícula Inválida. Insira uma nova matrícula: ");
    matricula = Console.ReadLine().ToUpper();
    continue;
    }
        matriculasparque += matricula;
        matriculasparque += "; ";
        contadorMatriculas++;

Console.Write($"Qual a matrícula {contadorMatriculas+1}? (ou 'FIM' para FIM): ");
matricula = Console.ReadLine().ToUpper();
}

//Apresentação de resultados
if (matriculasparque =="")
    Console.WriteLine($"Não existem matrículas na base de dados.");
else
Console.WriteLine($"A lista das matriculas é {matriculasparque}");