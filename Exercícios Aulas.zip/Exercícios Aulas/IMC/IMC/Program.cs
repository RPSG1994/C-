﻿/* Autor: Rui Gonçalves
 * Data:09052023*/

//definir variáveis
float peso, altura, imc;
string nome;

//atribuir variávies
peso = 90;
altura = 1.75f;
nome = "Rui";

//fórmula de cálculo
imc = peso / (altura * altura);

//apresentar resultado
Console.WriteLine($"O IMC do {nome} com o peso {peso} kg e da altura {altura} m e {imc}.");