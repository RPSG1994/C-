﻿/* Autor: Rui Gonçalves
Data:10-05-2023 */

//definir constantes
const int IDADE_MAXIMA = 5;
const int PATAS_CAO_OU_GATO = 4;
const int PATAS_PATO = 2;

//definir variáveis
int idade1, idade2, idade3, idade4;
string animal1 = " ", animal2 = " ", animal3 = " ", animal4 = " ";
int contadorpatas = 0;

//requerer dados dos animais
Console.Write("Animal 1: ");
animal1 = Console.ReadLine();
Console.Write("Idade Animal 1: ");
idade1 = int.Parse(Console.ReadLine());
Console.Write("Animal 2: ");
animal2 = Console.ReadLine();
Console.Write("Idade Animal 2: ");
idade2 = int.Parse(Console.ReadLine());
Console.Write("Animal 3: ");
animal3 = Console.ReadLine();
Console.Write("Idade Animal 3: ");
idade3 = int.Parse(Console.ReadLine());
Console.Write("Animal 4: ");
animal4 = Console.ReadLine();
Console.Write("Idade Animal 4: ");
idade4 = int.Parse(Console.ReadLine());

//teste lógico
if (idade1 <= IDADE_MAXIMA && (((animal1 == "cao" || animal1 == "cão") || animal1 == "gato"))) //opção de cão com til
    contadorpatas += PATAS_CAO_OU_GATO;
else if (idade1 <= IDADE_MAXIMA && animal1 == "pato")
    contadorpatas += PATAS_PATO;

if (idade2 <= IDADE_MAXIMA && (animal2 == "cao" || animal2 == "gato"))
    contadorpatas += PATAS_CAO_OU_GATO;
else if (idade2 <= IDADE_MAXIMA && animal2 == "pato")
    contadorpatas += PATAS_PATO;

if (idade3 <= IDADE_MAXIMA && (animal3 == "cao" || animal3 == "gato"))
    contadorpatas += PATAS_CAO_OU_GATO;
else if (idade3 <= IDADE_MAXIMA && animal3 == "pato")
    contadorpatas += PATAS_PATO;

if (idade4 <= IDADE_MAXIMA && (animal4 == "cao" || animal4 == "gato"))
    contadorpatas += PATAS_CAO_OU_GATO;
else if (idade4 <= IDADE_MAXIMA && animal4 == "pato")
    contadorpatas += PATAS_PATO;

//Apresentar resultados
Console.WriteLine($"O número total de patas válidas é {contadorpatas}");