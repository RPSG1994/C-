﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    public class Student
    {
        static int lastId = 0;

        //Construtor
        public Student()
        {
            lastId++;
            this.Id = lastId;
        }

        public int Id { get; }
        
        public string Name { get; set; }

        public Gender Gender { get; set; }

        public Course Course { get; set; }

        public Country Country { get; set; }
    }
}
