﻿//Variaveis
using Funcionalidades;

string opcao, name;
int age;
UserInteraction ui = new UserInteraction();

//Pedir idade
/*age = ui.AskForInt("Insert the age: ", 0, 120, "ERROR! WRONG NUMBER! Insert a new one: ");
Console.WriteLine("FIM");*/

name = ui.AskForString("Qual é o nome? ",TextType.LowerCase);
Console.WriteLine(name);
return;

do
{
	Console.Clear();
    Console.WriteLine("===============================MENU==================================");
    Console.WriteLine("<c> Clientes");
    Console.WriteLine("<f> Fornecedores");
    Console.WriteLine("<b> Bancos");
    Console.WriteLine("<s> Sair");
    Console.Write("Opção: ");
    opcao = Console.ReadLine().ToLower();

    switch (opcao)
	{
		case "c":
			Console.WriteLine("Clientes");
			return;
		case "f":
			Console.WriteLine("Fornecedores");
			return;
		case "b":
			Console.WriteLine("Bancos");
			return;
		case "s":
			return;
		default:
			Console.WriteLine("ERRO");
			break;
	}
	Console.ReadKey();

} while (opcao != "s");