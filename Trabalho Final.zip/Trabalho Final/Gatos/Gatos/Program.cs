﻿/* Autor: Rui Gonçalves
 * Data: 24-05-2023 */

/*Com o objetivo de promover a vacinação, um veterinário pretende atribuir um desconto nas vacinas para gatos mediante o seu comprimento [6𝑐𝑚; 10𝑐𝑚[.
Crie uma aplicação que solicite os dados de um gato e indique ao utilizador qual o desconto a atribuir com base no quadro seguinte.*/

//Constantes
const int DESCONTO_UM = 10;
const int DESCONTO_DOIS = 9;
const int DESCONTO_TRES = 8;
const int DESCONTO_QUATRO = 7;
const int DESCONTO_CINCO = 5;
const int COMPRIMENTO_UM = 6;
const int COMPRIMENTO_DOIS = 10;
const int COMPRIMENTO_TRES = 15;
const int COMPRIMENTO_QUATRO = 18;
const int COMPRIMENTO_CINCO = 25;

//Variáveis
float comprimento, desconto;
string genero;

//Pedido de imput do comprimento do gato
Console.Write("Qual o comprimento do gato? ");
comprimento = float.Parse(Console.ReadLine());

//Validação do comprimento do gato
if (comprimento < 0.0 || comprimento > 200.00)
{
    Console.Write("Comprimento Inválido! Qual o comprimento do gato? ");
    comprimento = float.Parse(Console.ReadLine());
}

//Pedido de imput do género do gato
Console.Write("Qual o género do gato? ");
genero = Console.ReadLine().ToUpper();

//Validação do género do gato
if (genero != "M" && genero != "F")
{
    Console.Write("Género Inválido! Qual o género do gato? ");
    genero = Console.ReadLine().ToUpper();
}

//Decisão do desconto a fazer
if (comprimento >= COMPRIMENTO_UM && comprimento < COMPRIMENTO_DOIS && genero == "F")
    desconto = DESCONTO_UM;
else if (comprimento >= COMPRIMENTO_DOIS && comprimento < COMPRIMENTO_TRES && genero == "M")
    desconto = DESCONTO_DOIS;
else if (comprimento >= COMPRIMENTO_TRES && comprimento < COMPRIMENTO_QUATRO && genero == "F")
    desconto = DESCONTO_TRES;
else if (comprimento >= COMPRIMENTO_QUATRO && comprimento < COMPRIMENTO_CINCO && (genero == "M" || genero == "F"))
    desconto = DESCONTO_QUATRO;
else
    desconto = DESCONTO_CINCO;

//Apresentação de Resultados
Console.Write($"O desconto atribuido a um gato do género {genero} e o comprimento {comprimento} cm é de {desconto}%.");