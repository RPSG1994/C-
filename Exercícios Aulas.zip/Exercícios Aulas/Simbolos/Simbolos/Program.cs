﻿//Variáveis
int numerosimbolos;
string simbolo;
int contador = 0;

//Pedir ao utilizador quantos asteriscos quer
Console.Write("Que simbolo queres? ");
simbolo = (Console.ReadLine());
Console.Write("Quantos simbolos queres? ");
numerosimbolos = int.Parse(Console.ReadLine());

//Loop de asteriscos
while (contador < numerosimbolos)
{
    Console.Write(simbolo);
    contador++;
}