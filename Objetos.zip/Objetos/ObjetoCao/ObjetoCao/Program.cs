﻿using ObjetoCao;

Cao Bobi = new Cao();