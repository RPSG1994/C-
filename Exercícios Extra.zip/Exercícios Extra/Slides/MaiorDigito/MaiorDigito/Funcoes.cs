﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaiorDigito
{
    public static class Funcoes
    {
        public static int MaiorAlgarismo(int numero)
        {
            int maior = 0;
            while (numero != 0)
            {
                int algarismo = numero % 10;
                if (algarismo > maior)
                {
                    maior = algarismo;
                }
                numero /= 10;
            }
            return maior;
        }
    }
}
