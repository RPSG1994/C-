﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BraceletMaker
{
    internal class Visitante
    {
        static int lastId = 0;
        /// <summary>
        /// Construtor de visitantes
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        public Visitante(string name)
        {
            this.Id = lastId++;
            this.Name = name;
            this.Entrance = false;
        }

        /// <summary>
        /// Propriedade de Id
        /// </summary>
        public int Id { get; }

        /// <summary>
        /// Propriedade de Nome
        /// </summary>
        public string Name { get; }

        /// <summary>
        /// Verifica se a entrada é permitida ou não
        /// </summary>
        /// <returns></returns>

        public bool Entrance { get; set; }

        /// <summary>
        /// Verifica se a entrada é permitida ou não
        /// </summary>
        /// <returns></returns>

        public void EntranceCleared()
        {
            this.Entrance = true;
        }
        public static string PrintBraceletContent(Visitante visitante)
        {
            return @$"
            *********************************
                ID              *  Name
            *********************************
                {visitante.Id}               *  {visitante.Name}
            *********************************";
        }
    }
}
