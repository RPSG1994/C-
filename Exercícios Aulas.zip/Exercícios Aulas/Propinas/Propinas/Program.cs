﻿/* Autor: Rui Gonçalves
 * Data: 11/05/2023*/

/*Crie uma aplicação que apresente o valor da propina de um aluno considerando os seguintes critérios: 
 * GRAU: mestrado - agravamento de 5%; licenciatura - agravamento de 2%.
 * IDADE: até 22 anos - 0% desconto; entre 22 e 30 anos - 10%; mais que 30 anos - 15%.*/

//Constantes
const int AGRAVAMENTO_MESTRADO = 5;
const int AGRAVAMENTO_LICENCIATURA = 2;
const int IDADE_MINIMA = 22;
const int IDADE_INTERMEDIA = 30;
const int DESCONTO_IDADE_22_30 = 10;
const int DESCONTO_IDADE_MAIS_30 = 15;

//Variáveis
string grauacademico;
int idade;
float propinabase, propinafinal, taxadograu, taxadaidade, desconto, agravamento;

//Recolha de dados
Console.Write("Insira a sua idade: ");
idade = int.Parse(Console.ReadLine());

//Validação dos dados inseridos
while (idade < 0 || idade > 100)
{
    Console.Write("ERRO! Insira a sua idade: ");
    idade = int.Parse(Console.ReadLine());
}

Console.Write("Insira o seu grau académico (l - licenciatura ou m - mestrado): ");
grauacademico = (Console.ReadLine().ToLower());

/* O "while" é uma estrutura de controle de fluxo em C# que permite a execução repetida de um bloco de código enquanto uma condição específica 
 * for verdadeira. O operador "!=" em C# é um operador de comparação que significa "não igual". 
 * É usado para verificar se dois valores não são iguais.*/

while (grauacademico != "l" && grauacademico != "m")
{
    Console.Write("Insira o grau académico novamente. Opções possíveis (l ou m): ");
    grauacademico = (Console.ReadLine().ToLower());
}

Console.Write("Insira o valor da propina: ");
propinabase = float.Parse(Console.ReadLine());

while (propinabase < 0)
{
    Console.Write("ERRO! Insira novamente o valor da propina: ");
    propinabase = float.Parse(Console.ReadLine());
}

//determinar taxas
switch (grauacademico)
{
    case "l":
        taxadograu = 1 + (AGRAVAMENTO_LICENCIATURA / 100f);
        break;
    case "m":
        taxadograu = 1 + (AGRAVAMENTO_MESTRADO / 100f);
        break;
    default:
        Console.Write("Operação Inválida");
        taxadograu = 0;
        break;
}

if (idade < IDADE_MINIMA)
    taxadaidade = 1;
else if (idade >= IDADE_MINIMA && idade <= IDADE_INTERMEDIA)
    taxadaidade = 1 - (DESCONTO_IDADE_22_30 / 100f);
else
    taxadaidade = 1 - (DESCONTO_IDADE_MAIS_30 / 100f);

//Cálculo da Propina com agravamentos
propinafinal = propinabase * taxadograu * taxadaidade;
desconto = propinabase - propinabase * taxadaidade;
agravamento = propinabase * taxadograu - propinabase;

//Apresentação do Resultado
Console.Write($"A propina a pagar será de:{propinafinal.ToString("### ###.#0")} euros com um desconto de{desconto.ToString("### ###.#0")} e um agravamento de{agravamento.ToString("### ###.#0")}.");