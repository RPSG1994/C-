﻿/* Autor: Rui Gonçalves
 * Data:20-05-2023*/

/* Numa determinada empresa há a necessidade de criar uma aplicação que
identifique o tipo de cliente em função do seu volume de compras anual*/

//Definir Constantes
const double CLIENTE_NORMAL = 5000.00;
const double CLIENTE_PROFISSIONAL = 20000.00;

//Definir Variáveis
double valorVendas;
string categoria;

//Imputs
Console.Write("Insira o volume de vendas: ");
valorVendas = double.Parse(Console.ReadLine());

while (valorVendas < 0)
{
    Console.Write("ERRO! Insira o valor das vendas de novo: ");
    valorVendas = double.Parse(Console.ReadLine());
}

//Decisão da categoria
if (valorVendas <= CLIENTE_NORMAL)
    categoria = "Cliente Normal";
else if (valorVendas > CLIENTE_NORMAL && valorVendas <= CLIENTE_PROFISSIONAL)
    categoria = "Cliente Profissional";
else
    categoria = "Cliente Empresarial";

//Apresentação de resultados
Console.Write($"A empresa com um volume de vendas de {valorVendas.ToString("### ###.00")} euros,corresponde à categoria: {categoria}.");