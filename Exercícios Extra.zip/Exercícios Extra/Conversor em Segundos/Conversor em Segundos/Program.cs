﻿/* Autor: Rui Gonçalves
 * Data: 20/05/2023*/

/* Elabore um algoritmo que leia um número inteiro representando segundos, e imprima o seu correspondente em horas, minutos e segundos.*/

//Variáveis
int segundos, horas, minutos, segundosTotais;

Console.Write("Quantos segundos queres converter? ");
segundosTotais = int.Parse(Console.ReadLine());

//Cálculos
horas = segundosTotais / 3600;
minutos = (segundosTotais % 3600)/ 60;
segundos = (segundosTotais % 3600) % 60;

//Apresentação de Resultados
Console.Write($"A conversão de {segundosTotais}s são {horas} h e {minutos} min e {segundos} s. ");