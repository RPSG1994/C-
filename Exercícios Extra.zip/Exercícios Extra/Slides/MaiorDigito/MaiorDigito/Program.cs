﻿using MaiorDigito;

/* Crie uma aplicação capaz de receber um número (inserido pelo utilizador) e de indicar na consola, qual o maior algarismo desse inteiro (exemplo 367283 o maior
algarismo é 8.*/

//Imputs
Console.Write("Qual o numero que quer saber qual o maior digito? ");
int numero = int.Parse(Console.ReadLine());

int maiorAlgarismo = Funcoes.MaiorAlgarismo(numero);

Console.WriteLine($"O maior algarismo do número é: {maiorAlgarismo}.");
