﻿/* Autor: Rui Gonçalves
 * Data: 20-05-2023*/

/* Na Unidade Curricular de português foi definida a nota mínima de 8,5 valores para o primeiro teste e de 9 valores para o segundo Foi também decidido que a nota
final à unidade seria a média aritmética entre as notas desses dois testes. A aprovação de um aluno é apenas possível se a nota final (média entre os dois
testes) for igual ou superior a 10 valores Se o aluno tiver uma nota final igual ou superior a 17 valores terá que fazer defesa oral Nestes casos, a nota final do aluno
será sempre inserida diretamente pelo professor Caso não compareça à defesa, o professor atribuirá a nota final de 17 valores */

//Constantes
const double NOTA_MINIMA_TESTE_UM = 8.5;
const double NOTA_MINIMA_TESTE_DOIS = 9.0;
const double NOTA_MINIMA = 10;
const double NOTA_DEFESA_ORAL = 17;

//Variáveis
string nomeAluno;
double notaTesteUm, notaTesteDois, notaFinal;

//Recolha de dados
Console.Write("Escreva o nome do aluno: ");
nomeAluno = Console.ReadLine();
Console.Write("Escreva a nota do primeiro teste: ");
notaTesteUm = double.Parse(Console.ReadLine());
Console.Write("Escreva a nota do segundo teste: ");
notaTesteDois = double.Parse(Console.ReadLine());

//Cálculo da média
notaFinal = (notaTesteUm + notaTesteDois) / 2;

//Decisões
if (notaTesteUm < NOTA_MINIMA_TESTE_UM || notaTesteDois < NOTA_MINIMA_TESTE_DOIS)
    Console.Write($"O aluno {nomeAluno} está reprovado!");
else if (notaFinal < NOTA_MINIMA)
    Console.Write($"O aluno {nomeAluno} está reprovado!");
else if (notaFinal >= NOTA_DEFESA_ORAL)
{
    Console.Write($"O aluno {nomeAluno} tem que se apresentar a uma defesa oral. A sua nota final foi de: ");
    notaFinal = double.Parse(Console.ReadLine());
    Console.Write($"O aluno {nomeAluno} teve a nota final de {notaFinal}");
}
else
    Console.Write($"O aluno {nomeAluno} teve uma nota final de {notaFinal}");