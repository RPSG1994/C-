﻿/* Autor: Rui Gonçalves
 * Data: 16/05/2023*/

/*Pretende
se criar uma aplicação que, perante várias inserções de números naturais (N0 pelo utilizador, calcule a quantidade de números pares inseridos
(considerar o zero não válido como par)*/

//Constante
const int DIVISOR = 2;

//Variáveis
int numero, contadorImpares = 0, contadorPares = 0;
string impares = "";
string pares = "";

//Recolha dos Imputs
Console.Write("Qual é o número que quer testar? (Insira número negativo para parar)");
numero = int.Parse(Console.ReadLine());

while (numero > 0)
{
    if (numero % DIVISOR != 0)
    {
        impares += numero; //Concatenar o resultado se for necessário concatenar .ToString
        impares += "; ";
        contadorImpares++;
    }

    else if (numero == 0)
        continue;

    else
    {
        pares += numero; //Concatenar o resultado se for necessário concatenar .ToString
        pares += "; ";
        contadorPares++;
    }
    Console.Write("Qual é o número que quer testar? (Insira número negativo para parar) ");
    numero = int.Parse(Console.ReadLine());
}

if (impares == "")
    Console.WriteLine($"Não existem números ímpares.");

Console.WriteLine($"Dos números inseridos existem {contadorImpares} números impares, que são {impares}.");
Console.WriteLine($"Dos números inseridos existem {contadorPares} números pares, que são {pares}.");