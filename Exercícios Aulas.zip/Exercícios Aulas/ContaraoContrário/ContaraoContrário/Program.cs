﻿//Variáveis
int contador=10;

Console.WriteLine("Os números de 10 a 0 são: ");

//Definir problema
while (contador >= 0)
{
    Console.WriteLine(contador);
    contador--;
}
