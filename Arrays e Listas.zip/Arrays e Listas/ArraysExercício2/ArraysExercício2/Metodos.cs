﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysExercício2
{
    internal static class Metodos
    {
        public static int PedeQuantidade()
        {
            int quantidade;
            Console.Write("Qual a quantidade de números que quer inserir? ");
            quantidade = int.Parse(Console.ReadLine());
            return quantidade;
        }

        public static int[] RecolheNumeros(int quantidade)
        {
            int[] numeros = new int[quantidade];
            int numero;
            int i = 0;

            do
            {
                Console.Write($"Insira o número {i + 1}: ");
                numero = int.Parse(Console.ReadLine());
                numeros[i] = numero;
                i++;
            } while (i < quantidade);

            return numeros;
        }

        public static double Media(int[] numeros)
        {
            double soma = 0;

            for (int i = 0; i < numeros.Length; i++)
                soma += numeros[i];

            double media = soma / (numeros.Length==0 ? 1 : numeros.Length);

            return media;
        }

        public static int MaiorNumero(int[] numeros)
        {
            int maximo = 0;

            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] > maximo)
                    maximo = numeros[i];
            }

            return maximo;
        }

        public static int MenorNumero(int[] numeros)
        {
            int minimo = 120;

            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] < minimo)
                    minimo = numeros[i];
            }

            return minimo;
        }


        public static int DiferencaNumeros(int[] numeros)
        {
            int maximo = MaiorNumero(numeros);
            int minimo = MenorNumero(numeros);
            int diferenca = maximo - minimo;

            return diferenca;
        }

        public static void Apresenta(double media, int maximo, int minimo, int diferenca)
        {
            Console.WriteLine($"A média dos valores inseridos é {media.ToString("###.00")}. ");
            Console.WriteLine($"O maior dos valores inseridos é {maximo}. ");
            Console.WriteLine($"O menor dos valores inseridos é {minimo}. ");
            Console.WriteLine($"A diferença entre o maior e o menor valor é {diferenca}. ");
        }
    }
}