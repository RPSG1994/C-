﻿/* Autor: Rui Gonçalves
 * Data: 16/05/2023*/

//Escreva na consola o fatorial de um número inserido pelo utilizador.;

//Variáveis
int fatorial = 1;
int numeroInserido;
int guardarImput;

Console.Write("De que número queres o factorial? ");
numeroInserido = int.Parse(Console.ReadLine());
guardarImput = numeroInserido;

//Validação do imput
while (numeroInserido < 0)
{
    Console.Write("ERRO! FATORIAL DE NÚMEROS NEGATIVOS NÃO EXISTE! De que número queres o factorial? ");
    numeroInserido = int.Parse(Console.ReadLine());
}

while (numeroInserido > 0) 
{
    fatorial *= numeroInserido;
    numeroInserido--; 
}

Console.Write($"O fatorial de {guardarImput} é {fatorial.ToString("### ### ###")}.");
