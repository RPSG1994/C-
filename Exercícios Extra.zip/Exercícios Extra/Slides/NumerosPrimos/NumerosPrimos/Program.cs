﻿/* Autor: Rui Gonçalves
 * Data: 23/05/2023 */

//Variáveis
int numero, numeroNegativo, divisor;
int contadorDivisores = 0;
string listaDivisores = "";

//Recolha de imputs
Console.Write("Que número quer saber se é primo? ");
numero = int.Parse(Console.ReadLine());
numeroNegativo = -numero;

//Percorrer todos os números de -numero a número

for (divisor = numeroNegativo; divisor <= numero; divisor++)
{
    if (divisor != 0 && numeroNegativo % divisor == 0)
    {
        contadorDivisores++;
        listaDivisores += divisor + "; ";
    }
}

//Saber se número é primo
if (contadorDivisores == 4)
    Console.WriteLine("O número é primo.");
else
    Console.WriteLine($"O número não é primo. A sua lista de divisores é: {listaDivisores}");