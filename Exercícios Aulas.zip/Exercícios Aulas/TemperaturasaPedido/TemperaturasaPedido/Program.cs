﻿/* Autor: Rui Gonçalves
 * Data: 16/05/2023*/

//Variáveis
double temperatura, soma = 0, media;
int contador = 0, numeroPacientes;

//Pedir ao utilizador quantos pacientes existem
Console.Write("Quantos pacientes existem? ");
numeroPacientes = int.Parse(Console.ReadLine());

//No exercício das temperaturas, garanta que a quantidadeTemperaturas inserida pelo utilizador é superior a zero...
while (numeroPacientes < 1)
{
    Console.WriteLine("ERRO! Impossível existirem menos de zero pacientes.");
    Console.Write("Quantos pacientes existem? ");
    numeroPacientes = int.Parse(Console.ReadLine());
}

//Recolher Temperaturas
while (contador < numeroPacientes)
{
    Console.Write($"Insira a temperatura {contador + 1}: ");
    temperatura = double.Parse(Console.ReadLine());
 
 while (temperatura <0)
{
        Console.Write($"Insira a temperatura {contador + 1}: ");
        temperatura = double.Parse(Console.ReadLine());
}
    soma += temperatura; //soma = soma + temperatura
    contador++; //contador = contador + 1
}