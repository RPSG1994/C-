﻿/* Autor: Rui Gonçalves
 * Data: 18/05/2023*/

//Crie uma aplicação que conte todos os inteiros inseridos pelo utilizador, que são divisiveis por 6.

//Variáveis
int numero = 0, contadorDivisiveis = 0, contadorNaoDiviveis = 0, divisor = 0; //Criar variável "resto" caso seja low code.
string divisiveis = "";
string naoDivisiveis = "";

while (numero >= 0)
{
   Console.Write("Qual é o numero que quer testar para divisor? ");
   divisor = int.Parse(Console.ReadLine());
   
   Console.Write($"Qual é o numero que que descobrir se é divisível por {divisor}? ");
   numero = int.Parse(Console.ReadLine()); 
    
    if (numero < 0)
        continue;
    
    if (numero % divisor == 0)
    {
        divisiveis += numero;
        divisiveis += "; ";
        contadorDivisiveis++;
    }
    else
    {
        naoDivisiveis += numero;
        naoDivisiveis += "; ";
        contadorNaoDiviveis++;
    }
}

//Resultados
Console.WriteLine($"Os números divisiveis por 6 introduzidos são, no notal, {contadorDivisiveis} e são {divisiveis}");
Console.Write($"Os números não divisíveis por 6 são, no total, {contadorNaoDiviveis} e são: {naoDivisiveis}");