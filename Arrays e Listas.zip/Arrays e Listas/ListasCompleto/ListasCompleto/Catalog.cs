﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListasCompleto
{
    internal class Catalog
    {
        // variables
        private static List<Product> products = new List<Product>();

        public static int Count { get { return products.Count; } }

        public static void New(Product product)
        {
            // o código não pode existir (não existem 2 produtos com o mesmo código)
            if (Exists(product.Code))
                throw new Exception("O produto que está a tentar guardar, já existe!");

            // o preço não pode ser zero
            if (product.Price <= 0)
                throw new Exception("Os preços não podem ser zero ou negativos!");

            // inserir o produto
            products.Add(product);
        }

        public static void New(int code, string description, Category category, Make make, float price, int stock)
        {
            //Variables
            Product product = new Product(code, description, category, make, price, stock);
            New(product);
        }

        public static Product Get(int code)
        {
            // variables
            int index;

            // o produto tem que existir
            if (!Exists(code))
                throw new Exception("O produto que pretende obter não existe!");

            // procurar o indice do produto pretendido
            index = GetIndex(code);

            // devolver o produto correspondente ao code
            return products[index];
        }

        public static bool Exists(int code)
        {
            return GetIndex(code) > -1;
        }

        private static int GetIndex(int code)
        {
            // variables
            int index = -1;

            // products o indice do code
            for (int i = 0; i < products.Count && index == -1; i++)
                if (products[i].Code == code)
                    index = i;

            // devolver o indice
            return index;
        }

        public static float GetPriceAverage()
        {
            // variables
            float sum = 0;
            int count = 0;

            // soma e conta os produtos da categoria -category-
            foreach (Product product in products)
            {
                sum += product.Price;
                count++;
            }

            // return the average
            return sum / (count == 0 ? 1 : count);
        }

        public static float GetPriceAverage(Category category)
        {
            // variables
            float sum = 0;
            int count = 0;

            // soma e conta os produtos da categoria -category-
            foreach (Product product in products)
            {
                if (product.Category == category)
                {
                    sum += product.Price;
                    count++;
                }
            }

            // return the average
            return sum / (count == 0 ? 1 : count);
        }

        public static float GetPriceAverage(Make make)
        {
            // variables
            float sum = 0;
            int count = 0;

            // soma e conta os produtos da categoria -category-
            foreach (Product product in products)
            {
                if (product.Make == make)
                {
                    sum += product.Price;
                    count++;
                }
            }

            // return the average
            return sum / (count == 0 ? 1 : count);
        }

        public static float GetPriceAverage(Category category, Make make)
        {
            // variables
            float sum = 0;
            int count = 0;

            // soma e conta os produtos da categoria -category-
            foreach (Product product in products)
            {
                if (product.Make == make && product.Category == category)
                {
                    sum += product.Price;
                    count++;
                }
            }

            // return the average
            return sum / (count == 0 ? 1 : count);
        }

        public static float GetMaxPrice()
        {
            // variables
            float maxPrice = 0;

            // Percorre todos os produtos e encontra o maior preço deles.
            foreach (Product product in products)

                if (product.Price > maxPrice)
                    maxPrice = product.Price;

            return maxPrice;
        }

        public static float GetMaxPrice(Category category)
        {
            // variables
            float maxPrice = 0;

            // Percorre todos os produtos e encontra o maior preço deles.
            foreach (Product product in products)

                if (product.Category == category && product.Price > maxPrice)
                    maxPrice = product.Price;

            return maxPrice;
        }

        public static int CountWithoutStock()
        {
            //Variable
            int count = 0;
            // Percorre todos os produtos e encontra o maior preço deles.
            foreach (Product product in products)

                if (product.Stock <= 0)
                    count++;

            return count;
        }

        public static int CountWithoutStock(Make make)
        {
            //Variable
            int count = 0;
            // Percorre todos os produtos e conta os sem stock de uma determinada marca
            foreach (Product product in products)

                if (product.Stock <= 0 && product.Make == make)
                    count++;

            return count;
        }

        public static int CountWithoutStock(Category category)
        {
            //Variable
            int count = 0;
            // Percorre todos os produtos e conta os sem stock de uma determinada categoria
            foreach (Product product in products)

                if (product.Stock <= 0 && product.Category == category)
                    count++;

            return count;
        }
    }
}