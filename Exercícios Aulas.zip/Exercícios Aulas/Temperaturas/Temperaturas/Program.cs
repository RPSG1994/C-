﻿/* Autor: Rui Gonçalves
Data:10-05-2023 */

//definir constantes
const double TEMP_MINIMA = 34.0;
const double TEMP_MAX = 45.0;
const double NIVEL_1 = 37.5;
const double NIVEL_2 = 38.0;
const double NIVEL_3 = 39.0;

//definir variáveis
double temperatura1, temperatura2, temperatura3, media; //declarar nomes melhores para as variáveis

//requerer dados dos doentes e abalizar temperaturas inseridas

/* O laço "do-while" começa com a palavra-chave "do", indicando que o código dentro do laço deve ser executado pelo menos uma vez. A mensagem "Temperatura doente 3: " é exibida no console.
A temperatura inserida pelo usuário é lida a partir da entrada do console usando Console.ReadLine() e convertida em um valor double usando double.Parse(). O valor da temperatura é armazenado na variável temperatura3.
A condição if (temperatura3 <= TEMP_MINIMA || temperatura3 >= TEMP_MAX) verifica se a temperatura inserida está fora do intervalo aceitável, onde TEMP_MINIMA e TEMP_MAX são constantes que definem os limites inferior e superior do intervalo aceitável.
Se a temperatura inserida estiver fora do intervalo aceitável, o programa exibe a mensagem de erro "Erro de inserção".
O laço "do-while" é encerrado com a palavra-chave "while", seguida da condição de repetição while (temperatura3 <= TEMP_MINIMA || temperatura3 >= TEMP_MAX), que verifica se a temperatura inserida está fora do intervalo aceitável. Se a condição for verdadeira, o laço será executado novamente, caso contrário, o laço será encerrado. Isso garante que o usuário insira uma temperatura válida antes de prosseguir com o programa.*/
do
{
    Console.WriteLine("Temperatura doente 1: ");
    temperatura1 = double.Parse(Console.ReadLine());
    if (temperatura1 <= TEMP_MINIMA || temperatura1 >= TEMP_MAX)
    {
        Console.WriteLine("Erro de inserção");
    }
} while (temperatura1 <= TEMP_MINIMA || temperatura1 >= TEMP_MAX);

do
{
    Console.WriteLine("Temperatura doente 2: ");
    temperatura2 = double.Parse(Console.ReadLine());
    if (temperatura2 <= TEMP_MINIMA || temperatura2 >= TEMP_MAX)
    {
        Console.WriteLine("Erro de inserção");
    }
} while (temperatura2 <= TEMP_MINIMA || temperatura2 >= TEMP_MAX);

do
{
    Console.WriteLine("Temperatura doente 3: ");
    temperatura3 = double.Parse(Console.ReadLine());
    if (temperatura3 <= TEMP_MINIMA || temperatura3 >= TEMP_MAX)
    {
        Console.WriteLine("Erro de inserção");
    }
} while (temperatura3 <= TEMP_MINIMA || temperatura3 >= TEMP_MAX);

//cálculo da média
media = (temperatura1 + temperatura2 + temperatura3) / 3;

//teste lógico
if (media <= NIVEL_1)
    Console.WriteLine($"Os doentes não necessitam de atenção.");
else if (media > NIVEL_1 && media <= NIVEL_2)
    Console.WriteLine($"Os doentes necessitam de alguma atenção - Medir de 4 em 4 horas");
else if (media > NIVEL_2 && media <= NIVEL_3)
    Console.WriteLine($"Os doentes necessitam de bastante atenção - Medir de 30 em 30 minutos");
else
    Console.WriteLine($"Os doentes necessitam de extrema atenção - Medir constantemente");