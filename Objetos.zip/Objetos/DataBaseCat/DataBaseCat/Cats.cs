﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DataBaseCat
{
    public class Cats
    {
        static int chipNumber = 1000;

        /// <summary>
        /// This is a cat in a zoo
        /// </summary>

        public Cats(string name)
        {
            chipNumber++;
            this.Chip = chipNumber;
            IsAwake = false;
        }

        
        /// <summary>
        /// This is the chip number
        /// </summary>
        public int Chip { get; set; }

        /// <summary>
        /// This is the cat's name
        /// </summary>
        
        public string Name { get; }
        
        /// <summary>
        /// This is the cat's breed
        /// </summary>

        public Breed Breed { get; set; }

        /// <summary>
        /// This is the cat's color
        /// </summary>

        public Color Color { get; set; }


        /// <summary>
        /// This is the cat's weight
        /// </summary>


        public double Weight { get; set; }


        /// <summary>
        /// This is the cat's age
        /// </summary>


        public int Age { get; set; }


        /// <summary>
        /// This is the cat's state (awake, sleep)
        /// </summary>


        public bool IsAwake { get; set; }

        /// <summary>
        /// Verify if the cat is awake
        /// </summary        
        public bool IsMeowing { get; }

        /// <summary>
        /// Verify if the cat is meowing
        /// </summary>

        public bool IsEating { get; }

        /// <summary>
        /// Verify if the cat is awake
        /// </summary>


        public void Awake()
        {
            if (IsAwake)
            {
                throw new Exception ($"The {Name} is already awake!");
            }
            //Abre os olhos
            //Boceja
            IsAwake = true;
            Console.WriteLine($"The {Name} is already awake...");
        }

        /// <summary>
        /// Verify if the cat is awake and if it is he starts meowing
        /// </summary>

        public void Meow()
        {
            if (!IsAwake)
            {
                Console.WriteLine("The cat is asleep! It can't meow.");
            }
            else
            Awake();
            Console.WriteLine($"The {Name} is meowing.");
        }
        /// <summary>
        /// Verify if the cat is awake and if it is he starts eating
        /// </summary>
        
        public void Eat()
        {
            if (!IsAwake)
            {
                Console.WriteLine("The cat is asleep! It can't eat.");
            }
            else
            Awake();
            Console.WriteLine($"The {Name} is eating.");
        }

        /// <summary>
        /// Gives a plate number to a cat
        /// </summary>
        /// 
        public static string GivePlate(int age, int chip, string name)
        {
            return @$"
          *********************************
          id     * age    * Name   *
          {chip} * {age}  * {name} * 

";
        }
    }
}