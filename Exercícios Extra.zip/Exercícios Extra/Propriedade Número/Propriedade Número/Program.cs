﻿/* Autor: Rui Gonçalves
 * Data: 15/05/2023*/

//Variáveis
int numero, milharesCentenas, dezenasUnidades, soma, quadrado;

//Imputs e controles
Console.Write("Insira um número de 4 algarismos (entre 1000 e 9999):");
numero = int.Parse(Console.ReadLine());

while (numero < 1000 || numero > 9999)
{
    Console.Write("ERRO! Insira um número de 4 algarismos (entre 1000 e 9999):");
    numero = int.Parse(Console.ReadLine());
}

//Cálculos
milharesCentenas = numero / 100;
dezenasUnidades = numero % 100;
soma = milharesCentenas + dezenasUnidades;
quadrado = soma * soma;

//Verificação
if (quadrado == numero)
    Console.Write($"O número {numero} respeita a propriedade.");    
else
    Console.Write($"O número {numero} não respeita a propriedade.");