﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListasCompleto
{
    internal class Product
    {
        public Product(int code, string description, Category category, Make make, float price, int stock)
        {
            Code = code;
            Description = description;
            Make = make;
            Category = category;
            Price = price;
            Stock = stock;
        }

        public int Code { get; set; }

        public string Description { get; set; }

        public Category Category { get; set; }

        public Make Make { get; set; }

        public float Price { get; set; }

        public int Stock { get; set; }
    }
}
