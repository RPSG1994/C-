﻿/* Autor: Rui Gonçalves
 * Data: 11/05/2023*/

//constantes
const float IVA_ISENTO = 0;
const float IVA_REDUZIDO = 6;
const float IVA_INTERMEDIO = 13;
const float IVA_NORMAL = 23;

//variáveis
float preco, taxaIva, pvp;
string descricao, codigo;
int codigoiva;

//Recolha de dados
Console.Write("CODIGO: ");
codigo = Console.ReadLine();
Console.Write("DESCRICAO: ");
descricao = Console.ReadLine();
Console.Write("PRECO: ");
preco = float.Parse(Console.ReadLine());
Console.Write("CODIGO IVA (0 = 0%; 1 = 6%; 2 = 13%; 3 = 23%): ");
codigoiva = int.Parse(Console.ReadLine());

//determinar taxa de IVA
switch (codigoiva)
{
    case 0:
        taxaIva = IVA_ISENTO;
        break;
    case 1:
        taxaIva = IVA_REDUZIDO;
        break;
    case 2:
        taxaIva = IVA_INTERMEDIO;
        break;
    case 3:
        taxaIva = IVA_NORMAL;
        break;
    default:
        taxaIva = -1;
        break;
}

//mostrar PVP
if (taxaIva < 0)
{
    Console.Write("O valor colocado não é válido");
    return;
}

//cálculo do PVP
pvp = preco * (1 + (taxaIva / 100));

//Apresentação do produto
Console.Write($"O produto {descricao} custa: {pvp.ToString("### ###.##")} euros.");