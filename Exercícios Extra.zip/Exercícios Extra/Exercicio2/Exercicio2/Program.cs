﻿/* Autor: Rui Gonçalves
 * Data: 10/05/2023*/

//definir variáveis

bool a = true, b = false, c = false, d = true, res1, res2, res3, res4;

//Testes lógicos
if (res1 = a || (b && c) || (!d || !a));
Console.WriteLine($"A afirmação 1 é {res1}");

if (res2 = !(!a || b) && (c || d)) ;
Console.WriteLine($"A afirmação 2 é {res2}");

if (res3 = b && !c || a && d) ;
Console.WriteLine($"A afirmação 3 é {res3}");

if (res4 = !a && !!c && d) ;
Console.WriteLine($"A afirmação 4 é {res4}");