﻿/* Autor: Rui Gonçalves
 * Data: 23/05/2023*/

/*Desenvolva um programa capaz de gerar e apresentar ao utilizador n números inteiros aleatórios entre 0 e 100*/

//Variáveis
int numeroMinimo, numeroMaximo, numeroAleatórios;
string listaNumeros= "";
Random random = new Random();

//Criação do visor de imput
Console.WriteLine("============GERADOR DE NÚMEROS ALEATÓRIOS=============");
Console.Write("Quantos numeros aleatórios quer? ");
numeroAleatórios = int.Parse(Console.ReadLine());
Console.Write("Qual o número mínimo? ");
numeroMinimo = int.Parse(Console.ReadLine());
Console.Write("Qual o número máximo? ");
numeroMaximo = int.Parse(Console.ReadLine());

//Apresentação dos Resultados
Console.WriteLine("A lista de números aleatórios gerada é: ");
for (; numeroAleatórios > 0; numeroAleatórios--)
{
    listaNumeros = random.Next(numeroMinimo,numeroMaximo).ToString();
    Console.WriteLine(listaNumeros);
}
