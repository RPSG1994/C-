﻿/* Autor: Rui Gonçalves
 * Data: 14/05/2023*/

/* Escreva um algoritmo que, dado um valor de binário T (em N.m) e as rotações/minuto (n) em que esse
binário ocorre, calcule a potência (P) de um motor, em cv. */

//Constantes
const double PI = Math.PI;
const double CONSTANTE = 60.75;

//Variáveis
double n, t, p;

//Pedido dos inputs
Console.Write("Insira um valor de binário T (em N.m): ");
t = float.Parse(Console.ReadLine());
Console.Write("Insira um valor de rotações/minuto: ");
n = float.Parse(Console.ReadLine());

//Cálculo da Potência
p = (2 * PI * n * t) / CONSTANTE;

//Apresentação do resultado
Console.WriteLine($"A potência do motor é de:{p.ToString("### ###.##")} cv.");