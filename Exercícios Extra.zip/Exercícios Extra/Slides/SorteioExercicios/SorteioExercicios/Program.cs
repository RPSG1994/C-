﻿/* Autor: Rui Gonçalves
 * Data: 28/05/2023*/

/*Desenvolva um programa capaz de gerar e apresentar ao utilizador n números inteiros aleatórios entre 198 e 217 sem repetir.*/

//Constantes
using SorteioExercicios;

const int NUMERO_MINIMO = 198;
const int NUMERO_MAXIMO = 217;

//Variáveis
int aleatorio, quantidadeNumeros;
string separador;

Console.Write("Quantos numeros aleatórios quer? ");
quantidadeNumeros = int.Parse(Console.ReadLine());

Console.Write("Que separador quer? ");
separador = Console.ReadLine();

Sorteio sorteio = new Sorteio();

do
{
    aleatorio = sorteio.DaNumeroAleatorio(NUMERO_MINIMO, NUMERO_MAXIMO);
} while (aleatorio == 216 || aleatorio == 198 || aleatorio == 213 || aleatorio == 210);

//Mostra Número Aleatório
Console.WriteLine($"Numero acabado de gerar: {aleatorio}");

//Mostra Números Aleatórios
//Console.WriteLine($"Numero acabado de gerar: {sorteio.DaNumerosAleatorios(NUMERO_MINIMO, NUMERO_MAXIMO, quantidadeNumeros, separador)}");