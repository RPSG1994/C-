﻿/* Autor: Rui Gonçalves
 * Data: 11/05/2023*/
//Implemente um switch que receba dois números e retorne a operação matemática correspondente (adição, subtração, multiplicação, divisão, resto da divisao inteira).

//variáveis
string operador;
float numero1, numero2, resultado;

//Recolha de dados
Console.Write("Insira o primeiro número: ");
numero1 = float.Parse(Console.ReadLine());
Console.Write("Insira o segundo número: ");
numero2 = float.Parse(Console.ReadLine());
Console.Write("Insira o operador matemático: ");
operador = Console.ReadLine();


//Evitar operações inválidas
while (operador != "+" && operador != "-" && operador != "*" && operador != "/")
{
    Console.Write("Insira o operador de novo: ");
    operador = Console.ReadLine();
}

//Evitar a divisão por 0
while (numero2 == 0 && operador == "/")
{
    Console.Write("Insira o segundo número: ");
    numero2 = float.Parse(Console.ReadLine());
}

//determinar operação
switch (operador)
{
    case "+":
        resultado = numero1 + numero2;
        break;
    case "-":
        resultado = numero1 - numero2;
        break;
    case "*":
        resultado = numero1 * numero2;
        break;
    case "/":
        resultado = numero1 / numero2;
        break;
    case "%":
        resultado = numero1 % numero2;
        break;
    default:
        Console.Write("Operação Inválida");
        return;
        break;
}
//Apresentação do resultado
Console.Write($"O resultado de {numero1} {operador} {numero2} é: {resultado}.");