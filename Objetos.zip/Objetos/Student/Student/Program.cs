﻿using Student;

Student.Student student1 = new Student.Student(); //Solução caso o nome seja igual em todo o lado

student1.Name = "Rui";
student1.Course = Course.English;
student1.Gender = Gender.Male;
student1.Country = Country.Portugal;

Console.WriteLine(student1.Id);