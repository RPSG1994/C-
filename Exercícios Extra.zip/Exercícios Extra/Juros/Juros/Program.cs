﻿/* Autor: Rui Gonçalves
 * Data: 14/05/2023*/

/* Escreva um algoritmo que leia o valor inicial, o número de períodos (em anos) e a taxa de juros e calcule
o valor final resultante.*/
//Variáveis
double valorInicial, valorFinal;
double taxa, taxadejuros;
int anos;

//Pedido dos inputs
Console.Write("Insira o valor inicial em euros: ");
valorInicial = float.Parse(Console.ReadLine());
while (valorInicial<0)
  Console.Write("Erro, valor negativo! Insira o valor inicial em euros: ");

Console.Write("Insira um valor de taxa de juros: ");
taxa = float.Parse(Console.ReadLine());
while (taxa < 0)
    Console.Write("Erro, valor negativo! Insira o valor inicial em euros: ");

Console.Write("Insira o número de anos: ");
anos = int.Parse(Console.ReadLine());
while (anos < 0)
    Console.Write("Erro, valor negativo! Insira o valor inicial em euros: ");

//Conversão da taxa de juro de valor para decimal
taxadejuros = taxa / 100;

//Cálculo do valor final
valorFinal = (valorInicial * Math.Pow((1 + taxadejuros), anos));

//Apresentação do resultado
Console.WriteLine($"O valor final pago é de:{valorFinal.ToString("### ###.##")} euros.");