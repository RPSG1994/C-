﻿/* Autor: Rui Gonçalves
Data:10-05-2023 */

//definir constantes
const int IDADE_MAXIMA = 5;

//definir variáveis
int idade1, idade2, idade3, idade4;
string animal1 = " ", animal2 = " ", animal3 = " ", animal4 = " ";
int contadorpatas = 0;

//requerer dados dos animais
Console.Write("Animal 1: ");
animal1 =Console.ReadLine();
Console.Write("Idade Animal 1: ");
idade1 = int.Parse(Console.ReadLine());
Console.Write("Animal 2: ");
animal2 = Console.ReadLine();
Console.WriteLine("Idade Animal 2: ");
idade2 = int.Parse(Console.ReadLine());
Console.Write("Animal 3: ");
animal3 = Console.ReadLine();
Console.Write("Idade Animal 3: ");
idade3 = int.Parse(Console.ReadLine());
Console.Write("Animal 4: ");
animal4 = Console.ReadLine();
Console.Write("Idade Animal 4: ");
idade4 = int.Parse(Console.ReadLine());

//teste lógico
if (idade1 <= IDADE_MAXIMA && animal1 == "cao")
    contadorpatas += 4;
else if (idade1 <= IDADE_MAXIMA && animal1 == "gato")
    contadorpatas += 4;
else if (idade1 <= IDADE_MAXIMA && animal1 == "pato")
    contadorpatas += 2;

if (idade2 <= IDADE_MAXIMA && animal2 == "cao")
    contadorpatas = contadorpatas += 4;
else if (idade2 <= IDADE_MAXIMA && animal2 == "gato")
    contadorpatas = contadorpatas += 4;
else if (idade2 <= IDADE_MAXIMA && animal2 == "pato")
    contadorpatas = contadorpatas += 2;

if (idade3 <= IDADE_MAXIMA && animal3 == "cao")
    contadorpatas = contadorpatas += 4;
else if (idade3 <= IDADE_MAXIMA && animal3 == "gato")
    contadorpatas = contadorpatas += 4;
else if (idade3 <= IDADE_MAXIMA && animal3 == "pato")
    contadorpatas = contadorpatas += 2;

if (idade4 <= IDADE_MAXIMA && animal4 == "cao")
    contadorpatas = contadorpatas += 4;
else if (idade4 <= IDADE_MAXIMA && animal4 == "gato")
    contadorpatas = contadorpatas += 4;
else if (idade4 <= IDADE_MAXIMA && animal4 == "pato")
    contadorpatas = contadorpatas += 2;

//Apresentar resultados
Console.WriteLine($"O número total de patas válidas é {contadorpatas}");