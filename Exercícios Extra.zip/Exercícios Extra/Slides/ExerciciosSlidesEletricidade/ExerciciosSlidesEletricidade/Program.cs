﻿/* Autor: Rui Gonçalves
 * Data: 20-05-2023*/

/* Para facilitar o controlo no consumo de energia, é necessário criar uma pequena aplicação que estime o valor da fatura mensal de um cliente, com base nos Kw
estimados de consumir num mês (estimativa de consumo num mês) Tenha em atenção que, o custo por Kw varia em função do tipo de cliente. */

//Constantes
const double PARTICULARES_CONTINENTE = 0.1865;
const double PARTICULARES_ILHAS = 0.1875;
const double PEQUENAS_EMPRESAS = 0.1754;
const double MEDIAS_GRANDES_EMPRESAS = 0.1592;
const double ESTADO_ORGANISMOS_PUBLICOS = 0.1311;
const double IVA = 23;

//Variáveis
double kW, fatura;
string opcao = "";

//Recolha de dados
Console.Write("Insira o seu consumo : ");
kW = double.Parse(Console.ReadLine());
Console.Write("Insira a opção de consumo (a - Particulares (Continente); b - Particulares (Ilhas); c - Pequenas empresas; d - Médias e grandes empresas; e - Estado e organismos públicos): ");
opcao = Console.ReadLine().ToLower();

//Decisão
switch (opcao)
{
    case "a":
        fatura = kW * (PARTICULARES_CONTINENTE * (1 + (IVA / 100)));
        break;
    case "b":
        fatura = kW * (PARTICULARES_ILHAS * (1 + (IVA / 100)));
        break;
    case "c":
        fatura = kW * (PEQUENAS_EMPRESAS * (1 + (IVA / 100)));
        break;
    case "d":
        fatura = kW * (MEDIAS_GRANDES_EMPRESAS * (1 + (IVA / 100)));
        break;
    case "e":
        fatura = kW * (ESTADO_ORGANISMOS_PUBLICOS * (1 + (IVA / 100)));
        break;
    default:
        Console.Write("IMPUT INVÁLIDO");
        fatura = 0;
        break;
}

//Apresentação de resultados
Console.Write($"O consumo faturado foi de {kW} kW e o custo é de{fatura.ToString("### ###.00")} euros. ");