﻿/* Autor: Rui Gonçalves
 * Data: 16/05/2023*/

//Pergunte ao professor n notas de uma turma, e apresente a melhor nota da turma.

//Variáveis
int numeroAlunos, contador = 0;
double notaMaxima = 0, nota;

//Recolha do numero de alunos
Console.Write("Quantos alunos existem? ");
numeroAlunos = int.Parse(Console.ReadLine());

//Validação de dados
while (numeroAlunos <= 0)
{
    Console.WriteLine("ERRO! Impossível existirem zero ou menos alunos.");
    Console.Write("Quantos alunos existem? ");
    numeroAlunos = int.Parse(Console.ReadLine());
}

//Recolha da maior nota
while (contador < numeroAlunos)
{
    Console.Write($"Insira a nota {contador + 1}: ");
    nota = double.Parse(Console.ReadLine());
    while (nota < 0 || nota > 20)
    {
        Console.Write($"ERRO! INSERIU UMA NOTA ERRADA! Insira a nota {contador + 1}: ");
        nota = double.Parse(Console.ReadLine());
    }
    if (nota >= notaMaxima)
        notaMaxima = nota;
contador++;
}
Console.WriteLine($"A maior nota da turma de {numeroAlunos} alunos é {notaMaxima}.");
