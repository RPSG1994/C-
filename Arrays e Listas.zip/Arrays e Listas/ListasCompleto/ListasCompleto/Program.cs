﻿using ListasCompleto;

//Isto usa o primeiro new
//Catalog.New(101, "HP X123", Category.Computers, Make.HP, 1150, 4);
//Catalog.New(102, "SAMSUNG ABC123", Category.Printers, Make.Samsung, 75, 10);
//Catalog.New(103, "DELL A123", Category.Screens, Make.Dell, 120, 0);


List<Product> productList = new List<Product>();
UserInterface userInterface = new UserInterface();

Make make = Make.Unknown;
Category category = Category.Unknown;
Category categorySearch = Category.Unknown;
Make makeSearch = Make.Unknown;
int numProducts, code, stock, decision, countWithoutStockMake, countWithoutStockCategory;
string description;
float price, averageMakePrice, averageCategoryPrice, averageCategoryMake;

do
{
    Console.Write("Digite o número de produtos que deseja adicionar: ");
    numProducts = int.Parse(Console.ReadLine());
} while (numProducts <= 0);

Console.Clear();

for (int i = 0; i < numProducts; i++)
{
    code = userInterface.AskForInt("Código do produto: ", 0, 2000000, "Valor inválido. Digite um número válido: ");
    description = userInterface.AskForString("Descrição do produto: ", TextType.UpperCase);
    price = userInterface.AskForFloat("Preço do produto: ", 0, 10000, "Valor inválido. Digite um número válido: ");
    make = userInterface.GetMake("Marca do produto (HP, Dell, Samsung): ", make);
    category = userInterface.GetCategory("Categoria do produto (Computers, Printers, Screens): ", category);
    stock = userInterface.AskForInt("Stock do produto: ", 0, 2000000, "Valor inválido. Digite um número válido: ");
    Catalog.New(code, description, category, make, price, stock);
}

Console.Clear();
do
{
    Console.Write("Que tipo de busca quer fazer? \n 1 - Preço Médio por Categoria \n 2 - Preço Médio por Marca \n 3 - Preço médio por Marca e Modelo \n 4 - Relatório Padrão \n 5 - Fechar \n");
    decision = int.Parse(Console.ReadLine());

    switch (decision)
    {
        case 1:
            {
                category = userInterface.GetCategory("Digite a categoria dos produtos (Computers, Printers, Screens): ", category);
                averageCategoryPrice = Catalog.GetPriceAverage(category);
                countWithoutStockCategory = Catalog.CountWithoutStock(category);
                Console.Clear();
                Console.WriteLine("=========================================RELATÓRIO DE PRODUTOS=============================================");
                Console.WriteLine($"O número de produtos sem stock é: {Catalog.CountWithoutStock()}");
                Console.WriteLine($"O número de produtos da categoria {category} sem stock é: {countWithoutStockCategory}");
                Console.WriteLine($"O produto mais caro tem o valor de: {Catalog.GetMaxPrice()} euros.");
                Console.WriteLine($"O valor médio dos produtos da loja é de: {Catalog.GetPriceAverage().ToString("### ##0.00")} euros.");
                Console.WriteLine($"A média de preço da categoria {category} é: {averageCategoryPrice.ToString("### ##0.00")} euros.");
                break;
            }
        case 2:
            {
                makeSearch = userInterface.GetMake("Digite a marca dos produtos (HP, Dell, Samsung): ", makeSearch);
                averageMakePrice = Catalog.GetPriceAverage(makeSearch);
                countWithoutStockMake = Catalog.CountWithoutStock(makeSearch);
                Console.Clear();
                Console.WriteLine("=========================================RELATÓRIO DE PRODUTOS=============================================");
                Console.WriteLine($"O número de produtos sem stock é: {Catalog.CountWithoutStock()}");
                Console.WriteLine($"O número de produtos sem stock da marca {makeSearch} é: {countWithoutStockMake}");
                Console.WriteLine($"O produto mais caro tem o valor de: {Catalog.GetMaxPrice()} euros.");
                Console.WriteLine($"O valor médio dos produtos da loja é de: {Catalog.GetPriceAverage().ToString("### ##0.00")} euros.");
                Console.WriteLine($"A média de preço da marca {makeSearch} é: {averageMakePrice.ToString("### ##0.00")} euros.");
                break;
            }
        case 3:
            {
                categorySearch = userInterface.GetCategory("Digite a categoria dos produtos (Computers, Printers, Screens): ", categorySearch);
                makeSearch = userInterface.GetMake("Digite a marca dos produtos (HP, Dell, Samsung): ", makeSearch);
                averageCategoryMake = Catalog.GetPriceAverage(categorySearch, makeSearch);
                Console.Clear();
                Console.WriteLine("=========================================RELATÓRIO DE PRODUTOS=============================================");
                Console.WriteLine($"O número de produtos sem stock é: {Catalog.CountWithoutStock()}");
                Console.WriteLine($"O produto mais caro tem o valor de: {Catalog.GetMaxPrice()} euros.");
                Console.WriteLine($"O valor médio dos produtos da loja é de: {Catalog.GetPriceAverage().ToString("### ##0.00")} euros.");
                Console.WriteLine($"A média de preço da marca {makeSearch} e categoria {categorySearch} é: {averageCategoryMake.ToString("### ##0.00")} euros.");
                break;
            }
        case 4:
            Console.WriteLine("=========================================RELATÓRIO DE PRODUTOS=============================================");
            Console.WriteLine($"O número de produtos sem stock é: {Catalog.CountWithoutStock()}");
            Console.WriteLine($"O produto mais caro tem o valor de: {Catalog.GetMaxPrice()} euros.");
            Console.WriteLine($"O valor médio dos produtos da loja é de: {Catalog.GetPriceAverage().ToString("### ##0.00")} euros.");
            break;

    } 
} while (decision != 1 || decision != 2 || decision != 3 || decision != 4);