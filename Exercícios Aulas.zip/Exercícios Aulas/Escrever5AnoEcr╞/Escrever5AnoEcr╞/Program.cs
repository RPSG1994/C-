﻿/* Autor: Rui Gonçalves
 * Data: 23-05-2023*/

//Constantes
const string A = "A";
const int NUMERO_CARACTERES = 5;

//Variáveis
int numeroRepeticoes = 0; 

while (numeroRepeticoes < NUMERO_CARACTERES)
{
    Console.Write(A);
    numeroRepeticoes++;
}