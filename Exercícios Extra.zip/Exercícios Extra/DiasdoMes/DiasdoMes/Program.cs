﻿/* Autor: Rui Gonçalves
 * Data: 11/05/2023*/
//Insira um número entre 1 e 12 [1 - Janeiro 12- Dezembro] e diga quantos dias tem

//constantes
const int DIAS_31 = 31;
const int DIAS_30 = 30;
const int DIAS_28 = 28;

// variáveis
int numeroInserido;
string mesdoAno;
int diasdoMes;

//pedir o dia
Console.Write("Insira um número entre 1 e 12 [1 - Janeiro 12- Dezembro]:");
numeroInserido = int.Parse(Console.ReadLine());

//descobrir quantos dias tem
switch (numeroInserido)
{
    case 1:
        mesdoAno = "Janeiro";
        diasdoMes = DIAS_31;
        break;
    case 2:
        mesdoAno = "Fevereiro";
        diasdoMes = DIAS_28;
        break;
    case 3:
        mesdoAno = "Março";
        diasdoMes = DIAS_31;
        break;
    case 4:
        mesdoAno = "Abril";
        diasdoMes = DIAS_30;
        break;
    case 5:
        mesdoAno = "Maio";
        diasdoMes = DIAS_31;
        break;
    case 6:
        mesdoAno = "Junho";
        diasdoMes = DIAS_30;
        break;
    case 7:
        mesdoAno = "Julho";
        diasdoMes = DIAS_31;
        break;
    case 8:
        mesdoAno = "Agosto";
        diasdoMes = DIAS_31;
        break;
    case 9:
        mesdoAno = "Setembro";
        diasdoMes = DIAS_30;
        break;
    case 10:
        mesdoAno = "Outubro";
        diasdoMes = DIAS_31;
        break;
    case 11:
        mesdoAno = "Novembro";
        diasdoMes = DIAS_30;
        break;
    case 12:
        mesdoAno = "Dezembro";
        diasdoMes = DIAS_31;
        break;
    default:
        mesdoAno = "";
        Console.WriteLine("Mês não encontrado");
        return;
        break;
}
Console.Write($"O mês do ano inserido é {mesdoAno} e tem {diasdoMes} dias num ano comum.");