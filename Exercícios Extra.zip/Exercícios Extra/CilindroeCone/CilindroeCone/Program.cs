﻿/* Autor: Rui Gonçalves
 * Data: 15/05/2023*/

//Constantes
const double PI = Math.PI;
const double UM_TERCO = (1.0 / 3.0);

//Variáveis
double raio, altura, volumeCone, volumeCilindro;
string unidades;

//Imput de valores e validação
Console.Write("Insira o raio do cilindro e do cone: ");
raio = double.Parse(Console.ReadLine());

while (raio < 0)
{
    Console.Write("ERRO! VALOR NEGATIVO! Insira o raio do cilindro e do cone: ");
    raio = double.Parse(Console.ReadLine());
}

Console.Write("Insira a altura do cilindro e do cone: ");
altura = double.Parse(Console.ReadLine());

while (altura < 0)
{
    Console.Write("ERRO! VALOR NEGATIVO! Insira a altura do cilindro e do cone: ");
    altura = double.Parse(Console.ReadLine());
}

Console.Write("Insira as unidades das medidas: ");
unidades = Console.ReadLine();

// Cálculos
volumeCilindro = PI * Math.Pow(raio, 2) * altura;
volumeCone = UM_TERCO * PI * Math.Pow(raio, 2) * altura;

//Apresentação dos resultados
Console.Write($"O volume do cilindro é de {volumeCilindro.ToString("###.##")} {unidades}^3 e do cone é de {volumeCone.ToString("###.##")} {unidades}^3.");