﻿/* Autor: Rui Gonçalves
 * Data: 15/05/2023*/

//Variáveis
int num, dezenas, unidades;
string extensoDezenas = "", extensoUnidades = "";

// Lê o número inteiro
Console.Write("Informe um número entre 20 e 99: ");
num = int.Parse(Console.ReadLine());

// Declara as variáveis para armazenar as dezenas e unidades
dezenas = num / 10;
unidades = num % 10;

// Define os valores por extenso das dezenas usando switch
switch (dezenas)
{
    case 2:
        extensoDezenas = "vinte";
        break;
    case 3:
        extensoDezenas = "trinta";
        break;
    case 4:
        extensoDezenas = "quarenta";
        break;
    case 5:
        extensoDezenas = "cinquenta";
        break;
    case 6:
        extensoDezenas = "sessenta";
        break;
    case 7:
        extensoDezenas = "setenta";
        break;
    case 8:
        extensoDezenas = "oitenta";
        break;
    case 9:
        extensoDezenas = "noventa";
        break;
}

// Define os valores por extenso das unidades usando switch
switch (unidades)
{
    case 1:
        extensoUnidades = "um";
        break;
    case 2:
        extensoUnidades = "dois";
        break;
    case 3:
        extensoUnidades = "três";
        break;
    case 4:
        extensoUnidades = "quatro";
        break;
    case 5:
        extensoUnidades = "cinco";
        break;
    case 6:
        extensoUnidades = "seis";
        break;
    case 7:
        extensoUnidades = "sete";
        break;
    case 8:
        extensoUnidades = "oito";
        break;
    case 9:
        extensoUnidades = "nove";
        break;
}

// Imprime o valor do número por extenso
Console.WriteLine($"O número introduzido foi o {extensoDezenas} e {extensoUnidades}.");