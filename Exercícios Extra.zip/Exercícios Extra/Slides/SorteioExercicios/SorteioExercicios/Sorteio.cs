﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SorteioExercicios
{
    public class Sorteio
    {
        public int DaNumeroAleatorio(int numeroInferior, int numeroSuperior) 
        {
            Random rnd = new Random();
            return rnd.Next(numeroInferior, numeroSuperior);
        }

        public string DaNumerosAleatorios(int numeroInferior, int numeroSuperior, int quantidadeNumeros, string separadorLista)
        {
            string lista = "";
            int aleatorio;

            //Soteio de números aleatórios
            for (int i = 0; i < quantidadeNumeros; i++)
            {
                aleatorio = DaNumeroAleatorio(numeroInferior, numeroSuperior);
                lista += aleatorio.ToString() + separadorLista;
            }
            //Devolver a lista
            return lista;
        }
    }
}
