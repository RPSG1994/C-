﻿/* Autor: Rui Gonçalves
 * Data: 24-05-2023 */

/*Foi efetuado um questionário a um grupo de pacientes num hospital. De entre as perguntas efetuadas a cada paciente, destaca-se o género, a idade e se gostaram do atendimento efetuado pelo profissional de saúde que os atendeu. Implemente uma aplicação capaz de calcular e informar:
• O número de inquiridos do género feminino e masculino, que esperaram mais de 2 horas para serem atendidos;
• Percentagem de pacientes do género feminino que não gostaram do atendimento do profissional de saúde que os atendeu;
• Quantidade de pacientes de género masculino, maiores de idade, que gostaram do atendimento do médico que os atendeu;
• Média do tempo de espera dos pacientes femininos que não gostaram do atendimento do profissional de saúde.*/

//Constantes
const int IDADE_MINIMA = 0;
const int IDADE_MAXIMA = 120;
const int TEMPO_DE_ESPERA_MAXIMO = 2;
const int MAIORIDADE = 18;

//Variáveis
int contadorMulheres = 0, idade, contadorMulheresMaisDuasHoras = 0, contadorMulheresNaoGostaram = 0, contadorHomensAdultosQueGostaram = 0, contadorHomensMaisDuasHoras = 0;
double tempoDeEspera, percentagem, mediaTempoDeEspera, somaTempoDeEspera = 0;
string genero, avaliacaoAtendimento;


do
{
    //Imputs necessários e validação dos mesmos
    Console.Write("Qual a idade da pessoa? [Insira -1 para terminar o registo]: ");
    idade = int.Parse(Console.ReadLine());

    if (idade == -1)
        break;

    while (idade < IDADE_MINIMA || idade > IDADE_MAXIMA)
    {
        Console.Write("IMPUT ERRADO! Qual a idade da pessoa? : ");
        idade = int.Parse(Console.ReadLine());
    }

    Console.Write("Qual o género da pessoa [M, F ou O]? ");
    genero = Console.ReadLine().ToUpper();

    while (genero != "M" && genero != "F" && genero != "O")
    {
        Console.Write("IMPUT ERRADO! Qual o género da pessoa [Insira M para masculino ou F para Feminino]? ");
        genero = Console.ReadLine().ToUpper();
    }

    Console.Write("Qual o tempo de espera? ");
    tempoDeEspera = double.Parse(Console.ReadLine());

    while (tempoDeEspera < 0)
    {
        Console.Write("IMPUT ERRADO! Qual o tempo de espera? ");
        tempoDeEspera = double.Parse(Console.ReadLine());
    }

    Console.Write("Gostou do atendimento [Sim ou Não]? ");
    avaliacaoAtendimento = Console.ReadLine().ToUpper();

    while (avaliacaoAtendimento != "SIM" && avaliacaoAtendimento != "NAO" && avaliacaoAtendimento != "NÃO")
    {
        Console.Write("IMPUT ERRADO! Gostou do atendimento [Sim ou Não]? ");
        avaliacaoAtendimento = Console.ReadLine().ToUpper();
    }

    //Avaliar Condições para cáluclos posteriores
   
    if (genero == "F")
        contadorMulheres++;

    if (tempoDeEspera > TEMPO_DE_ESPERA_MAXIMO && genero == "F")
        contadorMulheresMaisDuasHoras++;
    else if (tempoDeEspera > TEMPO_DE_ESPERA_MAXIMO && genero == "M")
        contadorHomensMaisDuasHoras++;

    if (genero == "M" && idade >= MAIORIDADE && avaliacaoAtendimento == "SIM")
        contadorHomensAdultosQueGostaram++;

    if (genero == "F" && (avaliacaoAtendimento == "NÃO" || avaliacaoAtendimento == "NAO"))
    {
        somaTempoDeEspera += tempoDeEspera;
        contadorMulheresNaoGostaram++;
    }

} while (idade != -1);

//Cálculos Necessários
percentagem = (contadorMulheresNaoGostaram * 1.00) / ((contadorMulheres == 0 ? 1 : contadorMulheres)) * 100;
mediaTempoDeEspera = (somaTempoDeEspera / (contadorMulheresNaoGostaram == 0 ? 1 : contadorMulheresNaoGostaram));

//Apresentação dos Resultados
Console.WriteLine($"O número de inquiridos do género feminino, que esperaram mais de 2 horas para serem atendidos foi de {contadorMulheresMaisDuasHoras} e do género masculino é de {contadorHomensMaisDuasHoras}.");
Console.WriteLine($"A percentagem de pacientes do género feminino que não gostaram do atendimento do profissional de saúde que os atendeu foi de {percentagem.ToString("##0.00")}%.");
Console.WriteLine($"A quantidade de pacientes de género masculino, maiores de idade, que gostaram do atendimento do médico que os atendeu foi de {contadorHomensAdultosQueGostaram}.");
Console.WriteLine($"A média do tempo de espera dos pacientes femininos que não gostaram do atendimento do profissional de saúde foi de {mediaTempoDeEspera.ToString("##0.00")} horas.");