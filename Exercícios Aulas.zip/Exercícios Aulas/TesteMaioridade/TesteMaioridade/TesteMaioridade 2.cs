﻿/* Autor: Rui Gonçalves
Data: 10/05/2023*/

//definir constantes
const int MAIORIDADE= 18;

//definir variáveis
string nome;
int idade;

// assignar valores às variáveis
Console.WriteLine("Insira o nome: ");
nome = Console.ReadLine();
Console.WriteLine("Insira a idade: ");
idade =int.Parse(Console.ReadLine());

//teste lógico + apresentação de resultados
if (idade >= MAIORIDADE)

    Console.WriteLine($"O {nome} é maior de idade.");

else

    Console.WriteLine("O {0} não é maior de idade", nome);

Console.WriteLine("The END!");
