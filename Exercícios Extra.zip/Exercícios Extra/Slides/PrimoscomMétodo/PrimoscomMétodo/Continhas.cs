﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimoscomMétodo
{
    internal class Continhas
    {
        /// <summary>
        /// Este método verifica se um número é primo ou não.
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public bool IsPrime(int number)
        {  //Caso especial de -1, 0 ou 1 afirmar que o número não é primo
            
            if (number == 1 || number == 0 || number ==-1)
                return false;

            //Devolver informação
            return GetNumberDivisors(Math.Abs(number)) == 2;

        }

        public int GetNumberDivisors(int number)
        {
            //Variáveis
            int divisores = 0;

            //Contar divisores

            for (int i = 2; i < number; i++) 
             if (number % i == 0)
                divisores++;

            return divisores + 2;
        }

        public string GetDivisorsList(int number, string separadorLista)
        {
            //Variáveis
            /* string lista = "";
             int contadorDivisores = 0, i;
             //Procurar os Divisores

             for (i = Math.Abs(number) * (-1); i <= number; contadorDivisores++)
             {
                 if (i == 0)
                     continue;

                 if (number % i == 0)
                 {
                     lista += i;
                     lista += ", ";

                 }

             }
             return lista; */

            string lista = "";
            int i;
            //Procurar os Divisores

            for (i = 2; i < number; i++)
                     
                if (number % i == 0)
                lista += i + separadorLista + (i * (-1)) + separadorLista;

            //Adicionar o próprio número e o 1
            lista += number + separadorLista + number * (-1) + separadorLista + 1 + separadorLista + -1 + separadorLista;
            return lista;
        }
    }
}