﻿/* Autor: Rui Gonçalves
 * Data: 20-05-2023*/

/* Um clube de futebol pretende um programa que lhe facilite o processo de classificação de atletas em categorias A tabela apresentada abaixo, define as
categorias existentes e também os intervalos de idade que especificam a categoria para cada atleta. Com o objetivo de promover as inscrições na categoria Juvenil, o clube oferece a
taxa de inscrição aos atletas com 11 e 12 anos Certifique se que o utilizador é lembrado desse facto na sua implementação */

//Variáveis
int idade;
string nomeAtleta;

//Recolha de dados
Console.Write("Insira a idade do futebolista: ");
nomeAtleta = Console.ReadLine();
Console.Write("Insira a idade do futebolista: ");
idade=int.Parse(Console.ReadLine());

//Decisão
switch (idade)
{
    case 11:
        Console.Write($"O futebolista {nomeAtleta} será Juvenil e terá a taxa de inscrição GRÁTIS.");
        break;
    case 12:
        Console.Write($"O futebolista {nomeAtleta} será Juvenil e terá a taxa de inscrição GRÁTIS.");
        break;
    case 13: case 14: case 15:
        Console.Write($"O futebolista {nomeAtleta} será Juvenil.");
        break;
    case 16: case 17: case 18: case 19: case 20:
        Console.Write($"O futebolista {nomeAtleta} será Júnior.");
        break;
    case 21: case 22: case 23: case 24: case 25:
        Console.Write($"O futebolista {nomeAtleta} será Sénior.");
        break;
    default:
        Console.Write("Categoria não prevista.");
        break;
}