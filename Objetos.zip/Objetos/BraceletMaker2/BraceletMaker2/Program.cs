﻿using BraceletMaker;

//Variáveis
string name = "";

Console.Write("Qual o nome do visitante 1? ");
name = Console.ReadLine();

Visitante visitante1 = new Visitante(name);

Console.WriteLine(Visitante.PrintBraceletContent(visitante1));
