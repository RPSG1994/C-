﻿/* Autor: Rui Gonçalves
 * Data: 20/05/2023*/

/* Um artista da nossa praça produz cubos de 2cm de aresta, que depois pinta com uma tinta
que adquire ao preço de 10€ por lata de 1,5dl. Com um dl de tinta o artista consegue pintar 5cm2 da superfície de um cubo. 
Calcule quanto custa pintar um cubo inteiro (seja sistemático). Nota: área do cubo = aresta*aresta*6*/

//Variáveis
double areaCubo, custoCubo, capacidade, aresta, precoLata, quantidadeTinta, tintaLata;

//Imputs
Console.Write("Qual a aresta do cubo? ");
aresta =double.Parse(Console.ReadLine());
Console.Write("Qual o preço da lata? ");
precoLata = double.Parse(Console.ReadLine());
Console.Write("Qual a capacidade de pintura por dl? ");
capacidade = double.Parse(Console.ReadLine());
Console.Write("Qual a quantidade de tinta da lata? ");
tintaLata = double.Parse(Console.ReadLine());


//Cálculos
areaCubo = 6 * aresta * aresta;
quantidadeTinta = areaCubo/capacidade;
custoCubo = (quantidadeTinta * precoLata)/tintaLata;

//Apresentação de Resultados
Console.Write($"Para pintar um cubo de área {areaCubo} cm^2 são necessários {quantidadeTinta.ToString("###.00")} dl e custa {custoCubo.ToString("###.00")} euros.");