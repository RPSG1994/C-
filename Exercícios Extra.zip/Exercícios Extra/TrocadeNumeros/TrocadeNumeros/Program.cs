﻿/* Autor: Rui Gonçalves
 * Data: 20-05-2023*/

//Variáveis
int numero1, numero2, numeroAuxiliar;

//Recolha de dados
Console.Write("Insira o número 1: ");
numero1= int.Parse(Console.ReadLine());
Console.Write("Insira o número 2: ");
numero2 = int.Parse(Console.ReadLine());

//Trocar os números
if (numero1 > numero2) 
{
    numeroAuxiliar = numero1;
    numero1 = numero2;
    numero2 = numeroAuxiliar;
}

Console.Write($"Os números inseridos por ordem crescente são {numero1} e {numero2}.");
