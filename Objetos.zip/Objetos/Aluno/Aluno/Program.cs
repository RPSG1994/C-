﻿//Variáveis
using Turma;

Aluno aluno1 = new Aluno();
Aluno aluno2 = new Aluno();

Console.WriteLine("Insira a nota 1 do aluno 1.");
aluno1.Nota1 = double.Parse(Console.ReadLine());

Console.WriteLine("Insira a nota 2 do aluno 1.");
aluno1.Nota2 = double.Parse(Console.ReadLine());

Console.WriteLine("Insira a nota 3 do aluno 1.");
aluno1.Nota3 = double.Parse(Console.ReadLine());

Console.WriteLine($"O aluno1 está aprovado: {(aluno1.EstariaAprovado(aluno1.Nota1,aluno1.Nota2,aluno1.Nota3) ? "SIM" : "NÃO")} com a média de {aluno1.CalculaMedia(aluno1.Nota1, aluno1.Nota2, aluno1.Nota3)}");

double media = aluno2.CalculaMedia(17, 14, 15.7);
Console.WriteLine($"A média é de: {media}");