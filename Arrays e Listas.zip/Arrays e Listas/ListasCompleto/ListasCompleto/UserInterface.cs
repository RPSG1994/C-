﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListasCompleto
{
    internal class UserInterface
    {
        /// <summary>
        /// Ask for an integer
        /// </summary>
        /// <param name="question">Pergunta</param>
        /// <param name="leftBound">Limite Inferior</param>
        /// <param name="rightBound">Limite Superior</param>
        /// <param name="failMessage">Mensagem de erro</param>
        /// <returns></returns>
        public int AskForInt(string question, int leftBound, int rightBound, string failMessage)
        {
            //Variáveis
            int inteiro;

            //Ask the question 
            Console.Write(question);

            //Get the int imput from user& verify the number
            do
            {

                inteiro = int.Parse(Console.ReadLine());

                if (inteiro < leftBound || inteiro > rightBound)
                    Console.Write(failMessage);

            } while (inteiro < leftBound || inteiro > rightBound);

            //Return the integer to the user
            return inteiro;
        }
        /// <summary>
        /// Ask the name of the cat
        /// </summary>
        /// <param name="question">Pergunta</param>
        /// <param name="textType">Letra da resposta</param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public string AskForString(string question, TextType textType)
        {
            string answer;
            //Ask the question 

            Console.Write(question);

            //Get the strig imput from user and convert to textType

            answer = Console.ReadLine();

            //convert to textType
            switch (textType)
            {
                case TextType.LowerCase:
                    answer = answer.ToLower();
                    break;
                case TextType.UpperCase:
                    answer = answer.ToUpper();
                    break;
                case TextType.Raw:
                    break;
                default:
                    throw new Exception("ERRO! NÃO PODES!");
            }

            //Return the string to the user
            return answer;
        }
        /// <summary>
        /// Ask for a float
        /// </summary>
        /// <param name="question">Pergunta</param>
        /// <param name="leftBound">Limite Inferior</param>
        /// <param name="rightBound">Limite Superior</param>
        /// <param name="failMessage">Mensagem de erro</param>
        /// <returns></returns>
        public float AskForFloat(string question, int leftBound, int rightBound, string failMessage)
        {
            //Variáveis
            float number;

            //Ask the question 
            Console.Write(question);

            //Get the int imput from user& verify the number
            do
            {

                number = float.Parse(Console.ReadLine());

                if (number < leftBound || number > rightBound)
                    Console.Write(failMessage);

            } while (number < leftBound || number > rightBound);

            //Return the integer to the user
            return number;
        }

        public Make GetMake(string question, Make makeInput)
        {
            Console.Write(question);
            string makeString = Console.ReadLine();

            if (Enum.TryParse(makeString, out Make selectedMake))
            {
                return selectedMake;
            }
            else
            {
                Console.Write("Marca inválida.");
                return makeInput;
            }
        }

        public Category GetCategory(string question, Category categoryInput)
        {
            Console.Write(question);
            string categoryString = Console.ReadLine();

            if (Enum.TryParse(categoryString, out Category selectedCategory))
            {
                return selectedCategory;
            }
            else
            {
                Console.Write("Categoria inválida.");
                return categoryInput;
            }
        }
    }
}