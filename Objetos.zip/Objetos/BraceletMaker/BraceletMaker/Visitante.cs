﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BraceletMaker
{
    internal class Visitante
    {
        /// <summary>
        /// Construtor de visitantes
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        public Visitante(int id, string name)
        {
            this.Id = id;
            this.Name = name;
        }

        /// <summary>
        /// Propriedade de Id
        /// </summary>
        public int Id { get;}

        /// <summary>
        /// Propriedade de nome
        /// </summary>
        public string Name { get;}

        /// <summary>
        /// Verifica se a entrada é permitida ou não
        /// </summary>
        /// <returns></returns>
      
        public void EntranceCleared()
        {
        }
        public string PrintBraceletContent()
        {
        return @$"
*********************************
   ID    *  Name
  {Id}   * {Name}
*********************************";
        }
    }
}