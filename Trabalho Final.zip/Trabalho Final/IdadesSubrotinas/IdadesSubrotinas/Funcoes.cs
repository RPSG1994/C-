﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace IdadesSubrotinas
{
    internal class Funcoes
    {
        const int LIMITE_INFERIOR = 65;
        const int LIMITE_SUPERIOR = 80;
        const int IDADE_MINIMA = 0;
        const int IDADE_MAXIMA = 120;

        /// <summary>
        /// Recebe, verifica e conta idades dentro de um determinado intervalo
        /// </summary>
        /// <returns></returns>
        
        public static int VerificaEContaIdades()
        {
            int idade, contador = 0;

            Console.Write("Qual a idade da pessoa? (Insira -1 para terminar o registo): ");
            idade = int.Parse(Console.ReadLine());

            while (idade > IDADE_MINIMA && idade < IDADE_MAXIMA && idade != -1)
            {

                if (idade >= LIMITE_INFERIOR && idade < LIMITE_SUPERIOR)
                {
                    contador++;
                }
                Console.Write("Qual a idade da pessoa? (Insira -1 para terminar o registo): ");
                idade = int.Parse(Console.ReadLine());
            }
            return contador;
        }
    }
}