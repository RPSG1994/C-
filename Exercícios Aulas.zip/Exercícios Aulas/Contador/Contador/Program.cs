﻿//Variáveis
string matricula1, matricula2;
string matriculas = " ";
string cor1, cor2;
int contador = 0;

//Recolha de dados
Console.Write("Insira a matrícula do carro 1: ");
matricula1 = Console.ReadLine();
Console.Write("Insira a cor do carro 1: ");
cor1 = Console.ReadLine();
Console.Write("Insira a matrícula do carro 2: ");
matricula2 = Console.ReadLine();
Console.Write("Insira a cor do carro 2: ");
cor2 = Console.ReadLine();

//Pontuação (amarelo = 1 e azul = 3)
if (cor1 == "amarelo")
{ 
    contador++;
    matriculas += matricula1;
    matriculas += " - ";    
}
else if (cor1 == "azul")
    contador += 3;

if (cor2 == "amarelo")
{
    contador++;
    matriculas += matricula2;
    matriculas += " - ";
}
else if (cor2 == "azul")
    contador += 3;

//Apresentar pontuação
Console.WriteLine($"O total da pontuação dos carros é {contador}.");
Console.WriteLine($"As matriculas de carros de cor azul são {matriculas}");