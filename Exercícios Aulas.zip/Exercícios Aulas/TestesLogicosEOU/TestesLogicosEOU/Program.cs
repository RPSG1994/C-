﻿/* Autor: Rui Gonçalves
 * Data: 10/05/2023*/

//escolher parâmetros
const double PESO_MINIMO = 50;
const double ALTURA_MINIMA = 1.6;

//definir variáveis
string nome, idade;
double peso, altura;

//recolher o nome e idade do utilizador
Console.WriteLine("Nome: ");
nome= Console.ReadLine();
Console.WriteLine("Idade: ");
idade = Console.ReadLine();

//recolher o peso e a altura
Console.WriteLine("Peso: ");
peso = double.Parse(Console.ReadLine());
Console.WriteLine("Altura: ");
altura = double.Parse(Console.ReadLine());

//mostrar a decisão final
if (altura>ALTURA_MINIMA && peso>=PESO_MINIMO)
    Console.WriteLine($"O utilizador {nome} de {idade} anos pode frequentar o ginásio.");
else if (altura <= ALTURA_MINIMA && peso >= PESO_MINIMO)
    Console.WriteLine($"O utilizador {nome} de {idade} anos não pode frequentar o ginásio porque não comeu muita sopa.");
else if (altura > ALTURA_MINIMA && peso < PESO_MINIMO)
    Console.WriteLine($"O utilizador {nome} de {idade} anos não pode frequentar o ginásio porque precisa de tomar mais batidos proteicos.");
else
    Console.WriteLine($"O utilizador {nome} de {idade} anos não pode frequentar o ginásio.");