﻿//Constantes
const int MULTIPLICADOR = 2;

//Variáveis
int numerosimbolos;
string simbolo;
int contador = 0;

//Pedir ao utilizador quantos asteriscos quer
Console.Write("Que simbolo queres? ");
simbolo = (Console.ReadLine());
Console.Write("Quantos simbolos queres? ");
numerosimbolos = int.Parse(Console.ReadLine());

//Passar para o dobro
numerosimbolos *= MULTIPLICADOR;

//Loop de asteriscos
while (contador < numerosimbolos)
{
    Console.Write(simbolo);
    contador++;
}