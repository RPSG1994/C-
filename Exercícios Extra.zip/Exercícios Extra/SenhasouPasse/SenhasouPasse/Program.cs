﻿/* Autor: Rui Gonçalves
 * Data: 11/05/2023*/

/*Criar um algoritmo para determinar se compensa viajar de senhas ou de passes*/

//constantes
const double PASSES = 40 + 74.10;
const double CP_SENHA = 3.25;
const double ANDANTE_SENHA = 1.70;

//variáveis
string mes;
int dias, numerosenhas;
double custosenhas, diferenca, senhaspagas;

//Recolha de dados
Console.Write("Insira o mês do ano: ");
mes = (Console.ReadLine().ToLower());

//determinar taxas
switch (mes)
{
    case "maio":
        dias = 12;
        break;
    case "junho":
        dias = 21;
        break;
    case "julho":
        dias = 21;
        break;
    case "agosto":
        dias = 13;
        break;
    case "setembro":
        dias = 21;
        break;
    case "outubro":
        dias = 21;
        break;
    case "novembro":
        dias = 18;
        break;
    default:
        Console.Write("Operação Inválida");
        dias = 0;
        break;
}
//Determinar o número de senhas necessárias
numerosenhas = dias * 2;

//Desconto por cada 10 senhas
if (numerosenhas >= 10 && numerosenhas < 20)
    senhaspagas = numerosenhas - 1;
else if (numerosenhas >= 20 && numerosenhas < 30)
    senhaspagas = numerosenhas - 2;
else if (numerosenhas >= 30 && numerosenhas < 40)
    senhaspagas = numerosenhas - 3;
else if (numerosenhas >= 40 && numerosenhas < 50)
    senhaspagas = numerosenhas - 4;
else
    senhaspagas = numerosenhas;

//Cálculo do custo a pagar e a diferença
custosenhas = senhaspagas * (ANDANTE_SENHA + CP_SENHA);
diferenca = PASSES - custosenhas;

//Comparação com o passe
if (custosenhas > PASSES)
    Console.Write($"Não compensa comprar senhas e a diferença de preço é de {diferenca.ToString("### ###.##")} euros.");
else
    Console.Write($"Compensa comprar senhas e a diferença é de {diferenca}");