﻿using Objetos;

Carro carro1 = new Carro();
Carro carro2 = new Carro();
Carro carro3 = new Carro();

carro1.Matricula = "90-50-UH";
Console.WriteLine($"A quilometragem do Carro2 é de {carro2.DaKm()} km.");
Console.WriteLine($"A cor do Carro 3 é {carro3.DaCor()}.");
Console.WriteLine($"O ano do Carro 1 é {carro1.DaAno()}.");
Console.WriteLine($"A matricula do Carro 1 é {carro1.DaMatricula()}.");