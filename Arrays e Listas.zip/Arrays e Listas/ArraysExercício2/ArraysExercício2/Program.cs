﻿using ArraysExercício2;

int[] numeros;
int quantidade, maximo, minimo, diferenca;
double media;

//Pede a quantidade de números
quantidade = Metodos.PedeQuantidade();

//Recolhe os numeros
numeros = Metodos.RecolheNumeros(quantidade);

//Faz a média
media = Metodos.Media(numeros);

//Recolhe o máximo e o mínimo
maximo = Metodos.MaiorNumero(numeros);
minimo = Metodos.MenorNumero(numeros);
diferenca = Metodos.DiferencaNumeros(numeros);

//Apresenta os resultados
Metodos.Apresenta(media, maximo, minimo, diferenca);