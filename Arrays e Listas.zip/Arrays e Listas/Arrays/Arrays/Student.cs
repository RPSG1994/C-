﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    internal class Student
    {
        //Construtor de Estudantes que recebe id e name da consola
        public Student(int id, string name) //ctor Faz um construtor de raiz
        {
            Id = id;
            Name = name;
        }
        public int Id { get; set; }
        public string Name { get; set; }
    }

}
