﻿using DataBaseCat;

int age;
double weight;
string name;
//Breed breedImput, breed;
//Color colorImput, color;

Cats cat1 = new Cats("Pantufa");
UserInterface ui = new UserInterface();
Cats cat2 = new Cats("Milu");

cat1.Age = 10;

// Pedido de Inputs
 name = ui.AskForName("What's the cat's age? ", TextType.UpperCase);
//age = ui.AskForAge("What's the cat's age? ", 0, 25, "ERROR! WRONG NUMBER! Insert a new one: ");
//weight = ui.AskForWeight("What's the cat's weight? ", 0, 20, "ERROR! WRONG NUMBER! Insert a new one: ");
//breed = ui.GetBreed("What's the cat's breed? ", cat1);
//color = ui.GetColor("What's the cat's color? ", cat1);

Console.WriteLine(Cats.GivePlate(cat1.Age,cat1.Chip, cat1.Name));

// Informação do Gato
//Console.WriteLine("============ INFORMAÇÃO DO GATO ==========");
//Console.WriteLine($"ID DO GATO: {cat1.Chip}");
//Console.WriteLine($"NOME DO GATO: ()
//Console.WriteLine($"IDADE DO GATO: {age}");
//Console.WriteLine($"PESO DO GATO: {weight}");
//Console.WriteLine($"RAÇA DO GATO: {breed}");
//Console.WriteLine($"COR DO GATO: {color}");
//Console.WriteLine("FIM");