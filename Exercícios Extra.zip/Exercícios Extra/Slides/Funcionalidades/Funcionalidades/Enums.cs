﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funcionalidades
{
    public enum TextType 
    {LowerCase, UpperCase, Raw}

    public enum Country 
    {Portugal, Spain, France}
}
