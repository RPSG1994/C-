﻿/* Autor: Rui Gonçalves
 * Data: 20/05/2023*/

/*Desenvolva um programa capaz de calcular o fatorial de um dado numero*/

//Variáveis
uint fatorial = 1, i, numero;

//Pedido de imputs
Console.Write("Que número quer calcular o factorial? ");
numero = uint.Parse(Console.ReadLine());

if (numero > 43)
{
    Console.Write("ERRO! Fatorial demasiado grande! Que número quer calcular o factorial? ");
    numero = uint.Parse(Console.ReadLine());
}
//Ciclo
for (i = numero; i > 0; i--)
{ 
    fatorial *= i; 
}

//Apresentação de resultados
Console.Write($"O factorial de {numero} é {fatorial.ToString("### ### ### ###")}.");