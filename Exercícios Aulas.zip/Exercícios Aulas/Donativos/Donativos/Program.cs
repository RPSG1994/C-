﻿/* Autor: Rui Gonçalves
 * Data: 18/05/2023*/

//Crie uma aplicação que indique o valor total dos donativos efetuados à entrada do centro de esposições de braga. No final, além da soma, apresente também a média dos donativos efetuada.

//Variáveis
double donativo, somaDosDonativos = 0, mediaDosDonativos = 0;
int doadores = 0;

Console.Write("Insira o valor do primeiro donativo (Colocar valor menor que zero para parar): ");
donativo = double.Parse(Console.ReadLine());

//Recolha de nomes, maior e menor idade
while (donativo >= 0)
{
    if (donativo <0)
        continue;
    
    else
    {
        somaDosDonativos += donativo;
        doadores++;
    }

Console.Write("Insira o valor do próximo donativo (Colocar valor menor que zero para parar): ");
donativo = double.Parse(Console.ReadLine());
}

//Cálculo da média
mediaDosDonativos = somaDosDonativos / (doadores == 0 ? 1 : doadores);

//Apresentação de resultados
Console.Write($"O valor dos donativos foi de {somaDosDonativos.ToString("###.00")} euros e o donativo médio foi de {mediaDosDonativos.ToString("###.00")} euros que provieram de {doadores}.");