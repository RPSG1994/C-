﻿using SomaPrimos;
SomarPrimos somarPrimos = new SomarPrimos();

Console.Write("Digite o primeiro número: ");
int lowerNumber = int.Parse(Console.ReadLine());

Console.Write ("Digite o segundo número: ");
int higherNumber = int.Parse(Console.ReadLine());

Console.Write("Digite o separador a usar: ");
string separadorLista = Console.ReadLine();

(lowerNumber, higherNumber) = somarPrimos.NumberSwap1(lowerNumber, higherNumber); 
int sumOfPrimes = somarPrimos.SumPrime(lowerNumber, higherNumber);

string listOfPrimes = somarPrimos.GivePrimes(lowerNumber, higherNumber, separadorLista);

Console.WriteLine($"A soma dos números primos entre {lowerNumber} e {higherNumber} é: {sumOfPrimes}");