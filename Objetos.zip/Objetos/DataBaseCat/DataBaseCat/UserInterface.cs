﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseCat
{
    internal class UserInterface
    {/// <summary>
    /// Ask the age of the cat
    /// </summary>
    /// <param name="question"></param>
    /// <param name="leftBound"></param>
    /// <param name="rightBound"></param>
    /// <param name="failMessage"></param>
    /// <returns></returns>
        public int AskForAge(string question, int leftBound, int rightBound, string failMessage)
        {
            //Variáveis
            int age;

            //Ask the question 
            Console.Write(question);

            //Get the int imput from user& verify the number
            do
            {

                age = int.Parse(Console.ReadLine());

                if (age < leftBound || age > rightBound)
                    Console.Write(failMessage);

            } while (age < leftBound || age > rightBound);

            //Return the integer to the user
            return age;
        }
        /// <summary>
        /// Ask the name of the cat
        /// </summary>
        /// <param name="question"></param>
        /// <param name="textType"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public string AskForString(string question, TextType textType)
        {
            string answer;
            //Ask the question 

            Console.Write(question);

            //Get the strig imput from user and convert to textType

            answer = Console.ReadLine();

            //convert to textType
            switch (textType)
            {
                case TextType.LowerCase:
                    answer = answer.ToLower();
                    break;
                case TextType.UpperCase:
                    answer = answer.ToUpper();
                    break;
                case TextType.Raw:
                    break;
                default:
                    throw new Exception("ERRO! NÃO PODES!");
            }

            //Return the string to the user
            return answer;
        }
        /// <summary>
        /// Ask the weight of the cat
        /// </summary>
        /// <param name="question"></param>
        /// <param name="leftBound"></param>
        /// <param name="rightBound"></param>
        /// <param name="failMessage"></param>
        /// <returns></returns>
        public double AskForWeight(string question, int leftBound, int rightBound, string failMessage)
        {
            //Variáveis
            double weight;

            //Ask the question 
            Console.Write(question);

            //Get the int imput from user& verify the number
            do
            {

                weight = double.Parse(Console.ReadLine());

                if (weight < leftBound || weight > rightBound)
                    Console.Write(failMessage);

            } while (weight < leftBound || weight > rightBound);

            //Return the integer to the user
            return weight;
        }

        /*public Breed GetBreed(string question, Cats cat)
        {
            string breedInput = Console.ReadLine();
            if (Enum.TryParse(breedInput, out Breed breed))
            {
                cat.Breed = breed;
            }
            else
            {
                Console.WriteLine("Invalid breed.");
            }
            return breed;
        }
        public Color GetColor(string question, Cats cat)
        {
            string colorInput = Console.ReadLine();
            if (Enum.TryParse(colorInput, out Color color))
            {
                cat.Color = color;
            }
            else
            {
                Console.WriteLine("Invalid color.");
            }
            return color;
        }*/
    }
}
