﻿//Variáveis
int quantidade = 0;

//Pedir ao utilizador o número que quer contar de forma decrescente
Console.Write("Até que número queres que conte ao contrário? ");
quantidade = int.Parse(Console.ReadLine());
Console.Clear();

//Definir problema
while (quantidade >= 0)
{
    Console.WriteLine(quantidade);
    quantidade--;
}
