﻿/* Autor: Rui Gonçalves
 * Data: 16/05/2023*/

//Escreva na consola todos os números múltiplos de 3 entre [x;y]

//Constante
const int DIVISOR = 3;

//Variáveis
int numero1, numero2, numeroAuxiliar;
string multiplos = "";
string naoMultiplos = "";

//Recolha dos Imputs
Console.Write("Qual é o primeiro numero? ");
numero1 = int.Parse(Console.ReadLine());
Console.Write("Qual é o segundo número? ");
numero2 = int.Parse(Console.ReadLine());

if (numero1>numero2)
{
    numeroAuxiliar = numero1;
    numero1 = numero2;
    numero2 = numeroAuxiliar;
}

Console.Write($"Os múltiplos entre {numero1} e {numero2} são: ");

while (numero1 <= numero2)
{
  if (numero1 % DIVISOR == 0)
  {
   multiplos += numero1; //Concatenar o resultado se for necessário concatenar .ToString
   multiplos += "; ";
  }
  else
  {
  naoMultiplos += numero1; //Concatenar o resultado se for necessário concatenar .ToString
  naoMultiplos += "; ";
  }
numero1++;
}
if (multiplos == "")
    Console.WriteLine($"Não existem multiplos entre {numero1} e {numero2}");

Console.Write($"{multiplos}e os não multiplos são {naoMultiplos}");