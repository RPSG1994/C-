﻿using VacinacaoGatos;

//Variáveis
float comprimento;
int desconto;
string genero;

//Chamada das funções
comprimento = Funcoes.VerificarComprimento();
genero = Funcoes.VerificarGenero();
desconto = Funcoes.CalcularDesconto(comprimento, genero);

//Apresentação de Resultados
Console.WriteLine($"O desconto atribuído a um gato do género {genero} e comprimento {comprimento} cm é de {desconto}%.");