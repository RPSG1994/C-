﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysModular
{
    internal static class ArrayUtils
    {
        /// <summary>
        /// Este método calcula a soma de um qualquer array de double.
        /// </summary>
        /// <param name="numeros">o conjunto de double para ser somado</param>
        /// <returns>devolve a soma</returns>
        public static double DaSoma(double[] numeros)
        {
            // variáveis
            double soma = 0;

            // fazer a soma
            for (int i = 0; i < numeros.Length; i++)
                soma += numeros[i];

            // devolver a soma
            return soma;
        }


        /// <summary>
        /// Este método calcula a média de um qualquer conjunto de double.
        /// </summary>
        /// <param name="numeros">o conjunto de double do qual se pretende fazer a média.</param>
        /// <returns>Devolve o valor da média</returns>
        public static double DaMedia(double[] numeros)
        {
            // variáveis
            double soma, media;

            // o número de elementos tem que ser maior que zero
            if (numeros.Length == 0)
                return 0;

            // calcular a soma
            soma = DaSoma(numeros);

            // calcular a média
            media = soma / numeros.Length;

            // devolver a média
            return media;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="origem"></param>
        /// <param name="threshold"></param>
        /// <returns></returns>
        public static double[] DaMaioresQue(double[] origem, double threshold)
        {
            // variáveis
            double[] destino;
            int quantidade;

            // saber quantos elementos são superiores ao threshold
            quantidade = DaQuantidadeMaioresQue(origem, threshold);

            // instanciar o array com essa dimensão
            destino = new double[quantidade];

            // copiar todos os elementos do array origem que são maiores que o threshold para o destino
            for (int i = 0, j = 0; i < origem.Length; i++)
            {
                if (origem[i] > threshold)
                {
                    destino[j] = origem[i];
                    j++;
                }
            }

            // devolver o array destino
            return destino;
        }

        /// <summary>
        /// Este método conta os elementos cujo valor é superior ao threshold indicado por argumento.
        /// </summary>
        /// <param name="origem">conjunto de dados double que contem os dados que serão testados</param>
        /// <param name="threshold">valor limite a partir do qual um valor do conjunto origem será considerado na contagem</param>
        /// <returns>quantidade de elementos existentes no conjunto origem, que são superiores ao threshold</returns>
        public static int DaQuantidadeMaioresQue(double[] origem, double threshold)
        {
            // variávies
            int quantidade = 0;

            // percorrer todos os elementos do array, para contar os que são superiores ao threshold
            for (int i = 0; i < origem.Length; i++)
                if (origem[i] > threshold)
                    quantidade++;

            // devolve a quantidade
            return quantidade;
        }
    }
}
