﻿/* Autor: Rui Gonçalves
 * Data: 20-05-2023*/

/* Devido à crise, o governo decidiu criar uma sobretaxa de IRS extraordinária de 3,5% sobre os salários cujo valor seja superior ao salário mínimo nacional. Esta nova taxa, apenas deve incidir sobre o valor que remanesce depois de subtraído o
salário mínimo ao salário do funcionário. Sugira um algoritmo para resolver o problema, acautelando a exceção prevista para os funcionários que apenas aufiram o salário mínimo nacional. */

//Constantes
const double SALARIO_MINIMO = 785.00;
const double TAXA = 3.5;

//Variáveis
string nomeFuncionario = "";
double salario, imposto;


//Recolha de dados
Console.Write("Escreva o nome do funcionário: ");
nomeFuncionario = Console.ReadLine();
Console.Write("Escreva o salário do funcionário: ");
salario = double.Parse(Console.ReadLine());

//Cálculo da taxa
if (salario > SALARIO_MINIMO)
{
    imposto = (salario - SALARIO_MINIMO) * (TAXA / 100);
    salario -=  imposto;
}

//Apresentação de resultados
Console.Write($"O salário final do {nomeFuncionario} é de{salario.ToString("### ###.00")} euros.");