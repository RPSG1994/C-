﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexBus
{
    public class Bus
    {
        private static int lastId = 0;
        /// <summary>
        /// Constructor of buses
        /// </summary>
        /// <param name="licensePlate"></param>
        /// <param name="make"></param>
        public Bus(string licensePlate, string make)
        {
            LicensePlate = licensePlate;
            Make = make;
            Id = lastId++;
        }
        
        /// <summary>
        /// Receives the value of Id
        /// </summary>
        
        public int Id { get; }
        
        /// <summary>
        /// Recebe o valor de license plate
        /// </summary>
        
        public string LicensePlate { get; set; }

        /// <summary>
        /// Receives the manufacture of the bus
        /// </summary>

        public string Make { get; }

        /// <summary>
        /// Calculates the next id of the next bus
        /// </summary>
        /// <returns></returns>
        public static int GetNextId()
        {
            return lastId + 1;
        }

        /// <summary>
        /// Recebe a matricula
        /// </summary>
        /// <returns></returns>
        
        public string GetLicencePlate()
        {
            return LicensePlate;
        }

        /// <summary>
        /// Changes the manufacture if receives Mercedes to Mercedes Benz
        /// </summary>
        /// <returns></returns>
        
        public string GetMake()
        {
            return (Make == "Mercedes" ? "Mercedes Benz" : Make);
        }

        /// <summary>
        /// Receive the manufacture and returns the weight of the bus
        /// </summary>
        /// <returns></returns>
        
        public int GetWeight()
        {
            return (Make == "Mercedes Benz" ? 5 : 6);
        }
    }
}