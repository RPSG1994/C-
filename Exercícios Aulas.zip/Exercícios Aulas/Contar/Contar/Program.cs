﻿//Variáveis
int contador = 0, numeroMax;

//Recolha do Imput
Console.Write("Até que número queres que conte? ");
numeroMax = int.Parse(Console.ReadLine());

//Apresentação do Resultado
Console.Write($"Os números inteiros até número são: \n");

while (contador < numeroMax)
{
    Console.WriteLine(contador + 1);
    contador++;
}