﻿using BraceletMaker;

Visitante visitante1 = new Visitante(1, "SARA");
Visitante visitante2 = new Visitante(2, "PEDRO");

Console.WriteLine(visitante1.PrintBraceletContent());
Console.WriteLine(visitante2.PrintBraceletContent());