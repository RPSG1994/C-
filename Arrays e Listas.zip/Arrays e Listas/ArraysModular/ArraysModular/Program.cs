﻿// constantes
using ArraysModular;

// variáveis
double[] numeros;
int quantidade;

//Pede a quantidade de doubles
quantidade = PedeQuantidade();

// carregar as notas
numeros = RecolheNumeros(quantidade);

// apresentar as notas superiores à média
MostraSuperiorMedia(numeros);

// Fim
Console.WriteLine("\n Fim");

// método que recolhe os elementos da consola

static int PedeQuantidade()
{
    int quantidade;
    Console.Write("Qual a quantidade de números que quer inserir? ");
    quantidade = int.Parse(Console.ReadLine());

    return quantidade;
}
static double[] RecolheNumeros(int quantity)
{
    // variáveis
    double[] numeros = new double[quantity];
    double numero;
    int i = 0;

    Console.Write($"Insira o número {i + 1}: ");
    numero = double.Parse(Console.ReadLine());

    // recolher as notas
    for (; i < quantity && numero >= 0; i++)
    {
        numeros[i] = numero;

        Console.Write($"Insira o número {i + 1}: ");
        numero = double.Parse(Console.ReadLine());
    }

    // devolver o array de notas
    return numeros;
}

// mostrar as notas superiores à media
static void MostraSuperiorMedia(double[] numeros)
{
    // variáveis
    double media;
    double[] subconjunto;

    // calcular a media
    media = ArrayUtils.DaMedia(numeros);

    // obter subconjunto de dados com o threshold na media
    subconjunto = ArrayUtils.DaMaioresQue(numeros, media);

    // apresentar os dados na consola
    Mostra($"NUMEROS MAIORES QUE: {media}", subconjunto);
}

static void Mostra(string titulo, double[] numeros)
{
    // apresenta relatório
    Console.WriteLine(titulo);

    // apresenta elementos
    for (int i = 0; i < numeros.Length; i++)
        Console.Write($"{numeros[i]}  ");
}