﻿/* Autor: Rui Gonçalves
 * Data: 23/05/2023 */

//Variáveis
using PrimoscomMétodo;

int number;
string separador;
Continhas continhas = new Continhas();

//Recolha de imputs
Console.Write("Que número quer saber se é primo? ");
number = int.Parse(Console.ReadLine());
Console.Write("Que separador dos primos quer? ");
separador = Console.ReadLine();

//Saber se é primo ou não
if (continhas.IsPrime(number))
    Console.Write($"O número {number} é primo.");
else
Console.Write($"A lista de divisores do número {number} são {continhas.GetDivisorsList(number, separador)}.");