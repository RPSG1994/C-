﻿//Constantes
const int NUMERO_TEMPERATURAS = 5;

//Variáveis
double temperatura, soma = 0, media;
int contador = 0;

//Recolha das Temperaturas
while (contador < NUMERO_TEMPERATURAS)
{
    Console.Write($"Insira a temperatura {contador + 1}: ");
    temperatura = double.Parse(Console.ReadLine());
    soma += temperatura;
    contador++;
}

//Cálculo da Média
media = soma / NUMERO_TEMPERATURAS;

//Apresentação do Resultado
Console.Write($"A média das {NUMERO_TEMPERATURAS} é de: {media.ToString("###.#0")}.");