﻿/* Autor: Rui Gonçalves
 * Data: 18/05/2023*/

/*O organismo público responsável pela meteorologia em Portugal necessita de fazer um estudo acerca da temperatura na cidade do Porto
Crie uma aplicação capaz de recolher durante n dias a temperatura, e no final, informar qual o pico de calor ocorrido, assim como a média das temperaturas
recolhidas. Em cada dia apenas será efetuada uma única recolha*/

//Variáveis
double temperatura = 0, temperaturaMaxima = 0, somaTemperaturas = 0, temperaturaMedia;
int dias = 0;

//Recolha de matriculas
while (temperatura != -1)
{
    Console.Write($"Qual a temperatura do dia {dias+1}? (ou '-1' para FIM): ");
    temperatura = double.Parse(Console.ReadLine());
    
    if (temperatura == -1)
        continue;
    
    if (temperatura > 0 && temperatura>= temperaturaMaxima)
    {
        somaTemperaturas += temperatura;
        dias++;
        temperaturaMaxima = temperatura;
    }        
}

// Verificação das temperaturas
if (dias == 0)
{
 Console.Write("Impossível calcular a média");
}
//Cálculo da média das temperaturas
temperaturaMedia = somaTemperaturas / dias;

//Apresentação de resultados
Console.Write($"A média das temperaturas é {temperaturaMedia.ToString("##.00")} graus e a temperatura máxima foi de {temperaturaMaxima.ToString("##.0")} graus.");