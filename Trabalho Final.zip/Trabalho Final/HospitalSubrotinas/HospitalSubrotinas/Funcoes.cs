﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSubrotinas
{
    internal class Funcoes
    {
        const int IDADE_MINIMA = 0;
        const int IDADE_MAXIMA = 120;
        const int TEMPO_DE_ESPERA_MAXIMO = 2;
        const int MAIORIDADE = 18;

        /// <summary>
        /// Verifica e regista a idade e termina o registo com -1
        /// </summary>
        /// <returns></returns>

        public static int VerificarIdade()
        {
            int idade;
            Console.Write("Qual a idade da pessoa? [Inserir -1 para terminar os registos] ");
            idade = int.Parse(Console.ReadLine());

            while (idade < IDADE_MINIMA || idade > IDADE_MAXIMA)
            {
                if (idade == -1)
                break;
                
                Console.Write("INPUT ERRADO! Qual a idade da pessoa? [Insira -1 para terminar o registro]: ");
                idade = int.Parse(Console.ReadLine());
            }
            return idade;
        }

        /// <summary>
        /// Verifica e regista o género do paciente
        /// </summary>
        /// <returns></returns>
        public static string VerificarGenero()
        {
            string genero;
            Console.Write("Qual o gênero da pessoa [M, F ou O]? ");
            genero = Console.ReadLine().ToUpper();

            while (genero != "M" && genero != "F" && genero != "O")
            {
                Console.Write("INPUT ERRADO! Qual o gênero da pessoa [Insira M para masculino ou F para Feminino]? ");
                genero = Console.ReadLine().ToUpper();
            }
            return genero;
        }
        /// <summary>
        /// Verifica e regista o tempo de espera do paciente
        /// </summary>
        /// <returns></returns>
        public static double VerificarTempoEspera()
        {
            double tempoDeEspera;
            Console.Write("Qual o tempo de espera? ");
            tempoDeEspera = double.Parse(Console.ReadLine());

            while (tempoDeEspera < 0)
            {
                Console.Write("INPUT ERRADO! Qual o tempo de espera? ");
                tempoDeEspera = double.Parse(Console.ReadLine());
            }
            return tempoDeEspera;
        }

        /// <summary>
        /// Verifica e regista a satisfação ao atendimento do paciente 
        /// </summary>
        /// <returns></returns>
        
        public static string VerificarAtendimento()
        {
            string avaliacaoAtendimento;
            Console.Write("Gostou do atendimento [Sim ou Não]? ");
            avaliacaoAtendimento = Console.ReadLine().ToUpper();

            while (avaliacaoAtendimento != "SIM" && avaliacaoAtendimento != "NAO" && avaliacaoAtendimento != "NÃO")
            {
                Console.Write("INPUT ERRADO! Gostou do atendimento [Sim ou Não]? ");
                avaliacaoAtendimento = Console.ReadLine().ToUpper();
            }
            return avaliacaoAtendimento;
        }

        /// <summary>
        /// Faz verificações para os cálculos posteriores
        /// </summary>
        /// <returns></returns>
        
        public static (int, int, int, int, double, int) AvaliarCondicoes()
        {
            int contadorMulheres = 0;
            int contadorMulheresMaisDuasHoras = 0;
            int contadorHomensMaisDuasHoras = 0;
            int contadorHomensAdultosQueGostaram = 0;
            double somaTempoDeEspera = 0;
            int contadorMulheresNaoGostaram = 0;
            int idade;

            //Este bloco de código é necessário para que a função AvaliarCondicoes repita as vezes que são necessarias
            do
            {
                idade = VerificarIdade();

                if (idade == -1)
                    break;

                string genero = VerificarGenero();
                double tempoDeEspera = VerificarTempoEspera();
                string avaliacaoAtendimento = VerificarAtendimento();

                if (genero == "F")
                    contadorMulheres++;

                if (tempoDeEspera > TEMPO_DE_ESPERA_MAXIMO && genero == "F")
                    contadorMulheresMaisDuasHoras++;
                else if (tempoDeEspera > TEMPO_DE_ESPERA_MAXIMO && genero == "M")
                    contadorHomensMaisDuasHoras++;

                if (genero == "M" && idade >= MAIORIDADE && avaliacaoAtendimento == "SIM")
                    contadorHomensAdultosQueGostaram++;

                if (genero == "F" && (avaliacaoAtendimento == "NÃO" || avaliacaoAtendimento == "NAO"))
                {
                    somaTempoDeEspera += tempoDeEspera;
                    contadorMulheresNaoGostaram++;
                }
            } while (idade != -1);

            return (contadorMulheres, contadorMulheresMaisDuasHoras, contadorHomensMaisDuasHoras, contadorHomensAdultosQueGostaram, somaTempoDeEspera, contadorMulheresNaoGostaram);
        }

        /// <summary>
        /// Calcular a média do tempo de espera dos pacientes.
        /// </summary>
        /// <param name="somaTempoDeEspera"></param>
        /// <param name="contadorMulheresNaoGostaram"></param>
        /// <returns></returns>
        
        public static double CalculoMediaTempoEspera(double somaTempoDeEspera, int contadorMulheresNaoGostaram)
        {
            double mediaTempoDeEspera;

            mediaTempoDeEspera = somaTempoDeEspera / (contadorMulheresNaoGostaram == 0 ? 1 : contadorMulheresNaoGostaram);

            return mediaTempoDeEspera;
        }

        /// <summary>
        /// Cálculo da percentagem de pacientes que não gostaram.
        /// </summary>
        /// <param name="somaTempoDeEspera"></param>
        /// <param name="contadorMulheresNaoGostaram"></param>
        /// <returns></returns>

        public static double CalculoPercentagem(int contadorMulheresNaoGostaram, int contadorMulheres)
        {
            double percentagem;

            percentagem = (contadorMulheresNaoGostaram * 1.0) / (contadorMulheres == 0 ? 1 : contadorMulheres) * 100;

            return percentagem;
        }
    }
}