﻿/* Autor: Rui Gonçalves
 * Data: 11/05/2023*/
//Digitar um número entre 1 e 6 e 1 - Domingo 7- Sábado

// variáveis
int numeroInserido;
string diaSemana;

//pedir o dia
Console.Write("Insira um número entre 1 e 7 [1 - Domingo 7- Sábado] ");
numeroInserido = int.Parse(Console.ReadLine());

//descobrir dia da semana
switch (numeroInserido)
{
	case 1: 
		diaSemana = "Domingo";
		break;
	case 2: 
		diaSemana = "Segunda-Feira";
		break;
	case 3:
		diaSemana = "Terça-Feira";
        break;
	case 4: 
		diaSemana = "Quarta-Feira";
        break;
	case 5:
		diaSemana = "Quinta-Feira";
        break;
	case 6:
        diaSemana = "Sexta-Feira";
        break;
	case 7:
		diaSemana = "Sábado";
		break;
    default:
		diaSemana = "";
		Console.WriteLine("Dia não encontrado");
		break;
}
Console.WriteLine($"Dia da semana inserido é: {diaSemana}");