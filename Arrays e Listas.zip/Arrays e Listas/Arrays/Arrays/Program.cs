﻿
using Arrays;

int N = 5;
Student[] students = new Student[N];
int id;
string name;

for (int i = 0; i < N; i++)
{
    //Recolher dados da consola
    Console.Write("Name: ");
    name = Console.ReadLine();
    Console.Write("Id: ");
    id = int.Parse(Console.ReadLine());

    //Adicionar ao array
    students[i]= new Student(id, name);
}

for (int i = 0; i < N; i++)
{
    Console.WriteLine(students[i].Name);
    Console.WriteLine(students[i].Id);
}


